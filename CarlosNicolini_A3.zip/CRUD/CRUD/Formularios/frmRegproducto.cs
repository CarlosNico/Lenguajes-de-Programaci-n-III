﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUD.Formularios
{
    public partial class frmRegproducto : Form
    {
        public frmRegproducto()
        {
            InitializeComponent();
        }

        private void btnagregar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=DESKTOP-5AVHSPI\\SQLEXPRESS;Initial Catalog=ZapateriaUmi;Integrated Security=True;Encrypt=False"))
            {
                if (txtnombre.Text == "" | txtprecio.Text == "" | txtnifproveedor.Text == "")
                {
                    MessageBox.Show("Por favor llenar todos los campos de campos");
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("INSERT into PRODUCTO (nombre, precio, nifProveedor) values ('" + txtnombre.Text + "','" + int.Parse(txtprecio.Text) + "','" + txtnifproveedor.Text + "')", cn);
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Se agrego exitosamente el producto " + txtnombre.Text + ".");
                    txtnombre.Clear();
                    txtprecio.Clear();
                    txtnifproveedor.Clear();
                }
            }
        }

        private void btnmodificar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=DESKTOP-5AVHSPI\\SQLEXPRESS;Initial Catalog=ZapateriaUmi;Integrated Security=True;Encrypt=False"))
            {
                if (txtnombre.Text == "" | txtprecio.Text == "")
                {
                    MessageBox.Show("Por favor llenar todos los campos de campos");
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("UPDATE PRODUCTO set nombre = '" + txtnombre.Text + "', precio = '" + int.Parse(txtprecio.Text) + "' where codigo = '" + txtcodigoproducto.Text + "'", cn);
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Se modifico exitosamente el producto " + txtnombre.Text + ".");
                    txtnombre.Clear();
                    txtprecio.Clear();
                    txtnifproveedor.Clear();
                    txtcodigoproducto.Clear();
                }
            }
        }

        private void btneliminar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=DESKTOP-5AVHSPI\\SQLEXPRESS;Initial Catalog=ZapateriaUmi;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("DELETE from PRODUCTO where codigo = '" + txtcodigoproducto.Text + "'", cn);
                cmd.CommandType = CommandType.Text;
                cn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Se elimino exitosamente a " + txtnombre.Text + ".");
                txtcodigoproducto.Clear();
            }
        }

        private void btnmostrar_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlConnection cn = new SqlConnection("Data Source=DESKTOP-5AVHSPI\\SQLEXPRESS;Initial Catalog=ZapateriaUmi;Integrated Security=True;Encrypt=False"))
            {
                SqlDataAdapter da = new SqlDataAdapter("select PRODUCTO.codigo AS Codigo_Producto, PRODUCTO.nombre AS Nombre_Producto, PRODUCTO.precio AS Precio, PROVEEDOR.nombre AS Nombre_Proveedor, PRODUCTO.nifProveedor AS ID_Proveedor FROM PRODUCTO inner join PROVEEDOR ON PRODUCTO.nifProveedor = PROVEEDOR.nif", cn);
                da.SelectCommand.CommandType = CommandType.Text;
                cn.Open();
                da.Fill(dt);
                dgvproducto.DataSource = dt;
            }
        }

        private void btnregresar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}

