﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUD.Formularios
{
    public partial class frmProddamas : Form
    {
        public frmProddamas()
        {
            InitializeComponent();
        }

        private void btnregresar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnagregar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Productos agregados al carrito");
            cbxd1.Checked = false;
            cbxd2.Checked = false;
            cbxd3.Checked = false;
            cbxd4.Checked = false;
            cbxd5.Checked = false;
            cbxd6.Checked = false;
            cbxd7.Checked = false;
            cbxd8.Checked = false;
            cbxd9.Checked = false;
            cbxd10.Checked = false;
            cbxd11.Checked = false;
            cbxd12.Checked = false;
            cbxd13.Checked = false;
            cbxd14.Checked = false;
            cbxd15.Checked = false;
            cbxd16.Checked = false;
            cbxd17.Checked = false;
            cbxd18.Checked = false;
            cbxd19.Checked = false;
            cbxd20.Checked = false;
            cbxd21.Checked = false;
            cbxd22.Checked = false;
            cbxd23.Checked = false;
            cbxd24.Checked = false;
            cbxd25.Checked = false;
            cbxd26.Checked = false;
            cbxd27.Checked = false;
            cbxd28.Checked = false;
            cbxd29.Checked = false;
            cbxd30.Checked = false;
            cbxd31.Checked = false;
            cbxd32.Checked = false;
            cbxd33.Checked = false;
            cbxd34.Checked = false;
            cbxd35.Checked = false;
            cbxd36.Checked = false;
            cbxd37.Checked = false;
            cbxd38.Checked = false;
            cbxd39.Checked = false;
            cbxd40.Checked = false;
            cbxd41.Checked = false;
            cbxd42.Checked = false;
            cbxd43.Checked = false;
            cbxd44.Checked = false;
            cbxd45.Checked = false;
            cbxd46.Checked = false;
            cbxd47.Checked = false;
            cbxd48.Checked = false;
            cbxd49.Checked = false;
            cbxd50.Checked = false;
            cbxd51.Checked = false;
            cbxd52.Checked = false;
            cbxd53.Checked = false;
            cbxd54.Checked = false;
            cbxd55.Checked = false;
            cbxd56.Checked = false;
            cbxd57.Checked = false;
            cbxd58.Checked = false;
            cbxd59.Checked = false;
            cbxd60.Checked = false;
            cbxd61.Checked = false;
            cbxd62.Checked = false;
            cbxd63.Checked = false;
            cbxd64.Checked = false;
            cbxd65.Checked = false;
            cbxd66.Checked = false;
            cbxd67.Checked = false;
            cbxd68.Checked = false;
            cbxd69.Checked = false;
            cbxd70.Checked = false;

        }
    }
}
