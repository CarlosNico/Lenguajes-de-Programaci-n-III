﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUD.Formularios
{
    public partial class frmCompras : Form
    {
        public frmCompras()
        {
            InitializeComponent();
        }

        private void btnmostrar_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlConnection cn = new SqlConnection("Data Source=DESKTOP-5AVHSPI\\SQLEXPRESS;Initial Catalog=ZapateriaUmi;Integrated Security=True;Encrypt=False"))
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT COMPRA.idcompra AS ID_Compra, COMPRA.idcliente AS Cliente_ID, CLIENTE.nombre AS nombre_cliente,CLIENTE.apellidos AS Apellido, PRODUCTO.nombre AS producto, PRODUCTO.precio AS Precio, COMPRA.fecha_venta AS Fecha_Venta FROM COMPRA INNER JOIN CLIENTE ON COMPRA.idcliente = CLIENTE.id inner join PRODUCTO ON COMPRA.codproducto = PRODUCTO.codigo", cn);
                da.SelectCommand.CommandType = CommandType.Text;
                cn.Open();
                da.Fill(dt);
                dgvcompras.DataSource = dt;
            }
        }

        private void btnregresar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btncompra_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=DESKTOP-5AVHSPI\\SQLEXPRESS;Initial Catalog=ZapateriaUmi;Integrated Security=True;Encrypt=False"))
            {
                if (txtcliente.Text == "" | txtproducto.Text == "")
                {
                    MessageBox.Show("Por favor llenar todos los campos de campos");
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("INSERT into COMPRA (idcliente, codproducto, fecha_venta) values ('" + txtcliente.Text + "','" + txtproducto.Text + "', (getdate()))", cn);
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Se registro exitosamente la compra");
                }
            }
        }

        private void btncomprascliente_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlConnection cn = new SqlConnection("Data Source=DESKTOP-5AVHSPI\\SQLEXPRESS;Initial Catalog=ZapateriaUmi;Integrated Security=True;Encrypt=False"))
            {
                if (txtcliente.Text == "")
                {
                    MessageBox.Show("Por favor llenar todos los campos de campos");
                }
                else
                {
                    SqlDataAdapter da = new SqlDataAdapter("SELECT COMPRA.idcompra AS ID_Compra, COMPRA.idcliente AS Cliente_ID, CLIENTE.nombre AS nombre_cliente,CLIENTE.apellidos AS Apellido, PRODUCTO.nombre AS producto, PRODUCTO.precio AS Precio, COMPRA.fecha_venta AS Fecha_Venta FROM COMPRA INNER JOIN CLIENTE ON COMPRA.idcliente = CLIENTE.id inner join PRODUCTO ON COMPRA.codproducto = PRODUCTO.codigo where idcliente = ('" + txtcliente.Text + "')", cn);
                    da.SelectCommand.CommandType = CommandType.Text;
                    cn.Open();
                    da.Fill(dt);
                    dgvcompras.DataSource = dt;
                }
            }
        }

        private void btncomprasyear_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlConnection cn = new SqlConnection("Data Source=DESKTOP-5AVHSPI\\SQLEXPRESS;Initial Catalog=ZapateriaUmi;Integrated Security=True;Encrypt=False"))
            {
                if (txtano.Text == "")
                {
                    MessageBox.Show("Por favor ingresar el año");
                }
                else
                {
                    SqlDataAdapter da = new SqlDataAdapter("SELECT COMPRA.idcompra AS ID_Compra, COMPRA.idcliente AS Cliente_ID, CLIENTE.nombre AS nombre_cliente,CLIENTE.apellidos AS Apellido, PRODUCTO.nombre AS producto, PRODUCTO.precio AS Precio, COMPRA.fecha_venta AS Fecha_Venta FROM COMPRA INNER JOIN CLIENTE ON COMPRA.idcliente = CLIENTE.id inner join PRODUCTO ON COMPRA.codproducto = PRODUCTO.codigo where YEAR(fecha_venta) = ('" + txtano.Text + "')", cn);
                    da.SelectCommand.CommandType = CommandType.Text;
                    cn.Open();
                    da.Fill(dt);
                    dgvcompras.DataSource = dt;
                }
            }
        }

        private void btncomprasproducto_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlConnection cn = new SqlConnection("Data Source=DESKTOP-5AVHSPI\\SQLEXPRESS;Initial Catalog=ZapateriaUmi;Integrated Security=True;Encrypt=False"))
            {
                if (txtproducto.Text == "")
                {
                    MessageBox.Show("Por favor ingresar el Id de producto");
                }
                else
                {
                    SqlDataAdapter da = new SqlDataAdapter("SELECT COMPRA.idcompra AS ID_Compra, COMPRA.idcliente AS Cliente_ID, CLIENTE.nombre AS nombre_cliente,CLIENTE.apellidos AS Apellido, PRODUCTO.nombre AS producto, PRODUCTO.precio AS Precio, COMPRA.fecha_venta AS Fecha_Venta FROM COMPRA INNER JOIN CLIENTE ON COMPRA.idcliente = CLIENTE.id inner join PRODUCTO ON COMPRA.codproducto = PRODUCTO.codigo where codproducto = ('" + txtproducto.Text + "')", cn);
                    da.SelectCommand.CommandType = CommandType.Text;
                    cn.Open();
                    da.Fill(dt);
                    dgvcompras.DataSource = dt;
                }
            }
        }
    }
}
