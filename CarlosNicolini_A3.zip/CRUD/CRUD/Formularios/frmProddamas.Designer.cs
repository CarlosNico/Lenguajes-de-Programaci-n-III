﻿namespace CRUD.Formularios
{
    partial class frmProddamas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProddamas));
            this.btnagregar = new System.Windows.Forms.Button();
            this.btnregresar = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.cbxd70 = new System.Windows.Forms.CheckBox();
            this.cbxd69 = new System.Windows.Forms.CheckBox();
            this.cbxd68 = new System.Windows.Forms.CheckBox();
            this.cbxd67 = new System.Windows.Forms.CheckBox();
            this.cbxd66 = new System.Windows.Forms.CheckBox();
            this.cbxd65 = new System.Windows.Forms.CheckBox();
            this.cbxd64 = new System.Windows.Forms.CheckBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.cbxd56 = new System.Windows.Forms.CheckBox();
            this.cbxd55 = new System.Windows.Forms.CheckBox();
            this.cbxd54 = new System.Windows.Forms.CheckBox();
            this.cbxd53 = new System.Windows.Forms.CheckBox();
            this.cbxd52 = new System.Windows.Forms.CheckBox();
            this.cbxd51 = new System.Windows.Forms.CheckBox();
            this.cbxd50 = new System.Windows.Forms.CheckBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.cbxd63 = new System.Windows.Forms.CheckBox();
            this.cbxd62 = new System.Windows.Forms.CheckBox();
            this.cbxd61 = new System.Windows.Forms.CheckBox();
            this.cbxd60 = new System.Windows.Forms.CheckBox();
            this.cbxd59 = new System.Windows.Forms.CheckBox();
            this.cbxd58 = new System.Windows.Forms.CheckBox();
            this.cbxd57 = new System.Windows.Forms.CheckBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.cbxd49 = new System.Windows.Forms.CheckBox();
            this.cbxd48 = new System.Windows.Forms.CheckBox();
            this.cbxd47 = new System.Windows.Forms.CheckBox();
            this.cbxd46 = new System.Windows.Forms.CheckBox();
            this.cbxd45 = new System.Windows.Forms.CheckBox();
            this.cbxd44 = new System.Windows.Forms.CheckBox();
            this.cbxd43 = new System.Windows.Forms.CheckBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.cbxd42 = new System.Windows.Forms.CheckBox();
            this.cbxd41 = new System.Windows.Forms.CheckBox();
            this.cbxd40 = new System.Windows.Forms.CheckBox();
            this.cbxd39 = new System.Windows.Forms.CheckBox();
            this.cbxd38 = new System.Windows.Forms.CheckBox();
            this.cbxd37 = new System.Windows.Forms.CheckBox();
            this.cbxd36 = new System.Windows.Forms.CheckBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.cbxd35 = new System.Windows.Forms.CheckBox();
            this.cbxd34 = new System.Windows.Forms.CheckBox();
            this.cbxd33 = new System.Windows.Forms.CheckBox();
            this.cbxd32 = new System.Windows.Forms.CheckBox();
            this.cbxd31 = new System.Windows.Forms.CheckBox();
            this.cbxd30 = new System.Windows.Forms.CheckBox();
            this.cbxd29 = new System.Windows.Forms.CheckBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.cbxd28 = new System.Windows.Forms.CheckBox();
            this.cbxd27 = new System.Windows.Forms.CheckBox();
            this.cbxd26 = new System.Windows.Forms.CheckBox();
            this.cbxd25 = new System.Windows.Forms.CheckBox();
            this.cbxd24 = new System.Windows.Forms.CheckBox();
            this.cbxd23 = new System.Windows.Forms.CheckBox();
            this.cbxd22 = new System.Windows.Forms.CheckBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.cbxd21 = new System.Windows.Forms.CheckBox();
            this.cbxd20 = new System.Windows.Forms.CheckBox();
            this.cbxd19 = new System.Windows.Forms.CheckBox();
            this.cbxd18 = new System.Windows.Forms.CheckBox();
            this.cbxd17 = new System.Windows.Forms.CheckBox();
            this.cbxd16 = new System.Windows.Forms.CheckBox();
            this.cbxd15 = new System.Windows.Forms.CheckBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.cbxd14 = new System.Windows.Forms.CheckBox();
            this.cbxd13 = new System.Windows.Forms.CheckBox();
            this.cbxd12 = new System.Windows.Forms.CheckBox();
            this.cbxd11 = new System.Windows.Forms.CheckBox();
            this.cbxd10 = new System.Windows.Forms.CheckBox();
            this.cbxd9 = new System.Windows.Forms.CheckBox();
            this.cbxd8 = new System.Windows.Forms.CheckBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.cbxd7 = new System.Windows.Forms.CheckBox();
            this.cbxd6 = new System.Windows.Forms.CheckBox();
            this.cbxd5 = new System.Windows.Forms.CheckBox();
            this.cbxd4 = new System.Windows.Forms.CheckBox();
            this.cbxd3 = new System.Windows.Forms.CheckBox();
            this.cbxd2 = new System.Windows.Forms.CheckBox();
            this.cbxd1 = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.groupBox11.SuspendLayout();
            this.groupBox18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.groupBox10.SuspendLayout();
            this.groupBox19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.groupBox17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.groupBox15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnagregar
            // 
            this.btnagregar.BackColor = System.Drawing.Color.Wheat;
            this.btnagregar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnagregar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnagregar.Location = new System.Drawing.Point(122, 386);
            this.btnagregar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnagregar.Name = "btnagregar";
            this.btnagregar.Size = new System.Drawing.Size(145, 36);
            this.btnagregar.TabIndex = 2;
            this.btnagregar.Text = "Agregar";
            this.btnagregar.UseVisualStyleBackColor = false;
            this.btnagregar.Click += new System.EventHandler(this.btnagregar_Click);
            // 
            // btnregresar
            // 
            this.btnregresar.BackColor = System.Drawing.Color.Goldenrod;
            this.btnregresar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnregresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnregresar.Location = new System.Drawing.Point(557, 386);
            this.btnregresar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnregresar.Name = "btnregresar";
            this.btnregresar.Size = new System.Drawing.Size(145, 36);
            this.btnregresar.TabIndex = 3;
            this.btnregresar.Text = "Regresar";
            this.btnregresar.UseVisualStyleBackColor = false;
            this.btnregresar.Click += new System.EventHandler(this.btnregresar_Click);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.groupBox12);
            this.panel1.Controls.Add(this.groupBox11);
            this.panel1.Controls.Add(this.groupBox10);
            this.panel1.Controls.Add(this.groupBox9);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.groupBox6);
            this.panel1.Controls.Add(this.groupBox5);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Location = new System.Drawing.Point(15, 12);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(844, 343);
            this.panel1.TabIndex = 14;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.label18);
            this.groupBox12.Controls.Add(this.label17);
            this.groupBox12.Controls.Add(this.groupBox20);
            this.groupBox12.Controls.Add(this.pictureBox10);
            this.groupBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox12.Location = new System.Drawing.Point(412, 455);
            this.groupBox12.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox12.Size = new System.Drawing.Size(401, 107);
            this.groupBox12.TabIndex = 10;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Sandalia c/ correas";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(133, 61);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(79, 13);
            this.label18.TabIndex = 15;
            this.label18.Text = "Precio $ 730";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(133, 35);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(83, 13);
            this.label17.TabIndex = 13;
            this.label17.Text = "Color: Blanco";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.cbxd70);
            this.groupBox20.Controls.Add(this.cbxd69);
            this.groupBox20.Controls.Add(this.cbxd68);
            this.groupBox20.Controls.Add(this.cbxd67);
            this.groupBox20.Controls.Add(this.cbxd66);
            this.groupBox20.Controls.Add(this.cbxd65);
            this.groupBox20.Controls.Add(this.cbxd64);
            this.groupBox20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox20.Location = new System.Drawing.Point(239, 12);
            this.groupBox20.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox20.Size = new System.Drawing.Size(154, 85);
            this.groupBox20.TabIndex = 9;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Tallas";
            // 
            // cbxd70
            // 
            this.cbxd70.AutoSize = true;
            this.cbxd70.Location = new System.Drawing.Point(7, 65);
            this.cbxd70.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd70.Name = "cbxd70";
            this.cbxd70.Size = new System.Drawing.Size(40, 17);
            this.cbxd70.TabIndex = 6;
            this.cbxd70.Text = "27";
            this.cbxd70.UseVisualStyleBackColor = true;
            // 
            // cbxd69
            // 
            this.cbxd69.AutoSize = true;
            this.cbxd69.Location = new System.Drawing.Point(110, 42);
            this.cbxd69.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd69.Name = "cbxd69";
            this.cbxd69.Size = new System.Drawing.Size(40, 17);
            this.cbxd69.TabIndex = 5;
            this.cbxd69.Text = "26";
            this.cbxd69.UseVisualStyleBackColor = true;
            // 
            // cbxd68
            // 
            this.cbxd68.AutoSize = true;
            this.cbxd68.Location = new System.Drawing.Point(58, 42);
            this.cbxd68.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd68.Name = "cbxd68";
            this.cbxd68.Size = new System.Drawing.Size(40, 17);
            this.cbxd68.TabIndex = 4;
            this.cbxd68.Text = "25";
            this.cbxd68.UseVisualStyleBackColor = true;
            // 
            // cbxd67
            // 
            this.cbxd67.AutoSize = true;
            this.cbxd67.Location = new System.Drawing.Point(7, 42);
            this.cbxd67.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd67.Name = "cbxd67";
            this.cbxd67.Size = new System.Drawing.Size(40, 17);
            this.cbxd67.TabIndex = 3;
            this.cbxd67.Text = "24";
            this.cbxd67.UseVisualStyleBackColor = true;
            // 
            // cbxd66
            // 
            this.cbxd66.AutoSize = true;
            this.cbxd66.Location = new System.Drawing.Point(110, 19);
            this.cbxd66.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd66.Name = "cbxd66";
            this.cbxd66.Size = new System.Drawing.Size(40, 17);
            this.cbxd66.TabIndex = 2;
            this.cbxd66.Text = "23";
            this.cbxd66.UseVisualStyleBackColor = true;
            // 
            // cbxd65
            // 
            this.cbxd65.AutoSize = true;
            this.cbxd65.Location = new System.Drawing.Point(58, 19);
            this.cbxd65.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd65.Name = "cbxd65";
            this.cbxd65.Size = new System.Drawing.Size(40, 17);
            this.cbxd65.TabIndex = 1;
            this.cbxd65.Text = "22";
            this.cbxd65.UseVisualStyleBackColor = true;
            // 
            // cbxd64
            // 
            this.cbxd64.AutoSize = true;
            this.cbxd64.Location = new System.Drawing.Point(7, 19);
            this.cbxd64.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd64.Name = "cbxd64";
            this.cbxd64.Size = new System.Drawing.Size(40, 17);
            this.cbxd64.TabIndex = 0;
            this.cbxd64.Text = "21";
            this.cbxd64.UseVisualStyleBackColor = true;
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox10.BackgroundImage")));
            this.pictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox10.Location = new System.Drawing.Point(6, 19);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(117, 81);
            this.pictureBox10.TabIndex = 0;
            this.pictureBox10.TabStop = false;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label16);
            this.groupBox11.Controls.Add(this.label15);
            this.groupBox11.Controls.Add(this.groupBox18);
            this.groupBox11.Controls.Add(this.pictureBox9);
            this.groupBox11.Location = new System.Drawing.Point(414, 342);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox11.Size = new System.Drawing.Size(401, 107);
            this.groupBox11.TabIndex = 9;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Zapato sueco tacon cuadrado";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(135, 62);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(79, 13);
            this.label16.TabIndex = 14;
            this.label16.Text = "Precio $ 300";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(131, 32);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(78, 13);
            this.label15.TabIndex = 13;
            this.label15.Text = "Color: Negro";
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.cbxd56);
            this.groupBox18.Controls.Add(this.cbxd55);
            this.groupBox18.Controls.Add(this.cbxd54);
            this.groupBox18.Controls.Add(this.cbxd53);
            this.groupBox18.Controls.Add(this.cbxd52);
            this.groupBox18.Controls.Add(this.cbxd51);
            this.groupBox18.Controls.Add(this.cbxd50);
            this.groupBox18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox18.Location = new System.Drawing.Point(237, 13);
            this.groupBox18.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox18.Size = new System.Drawing.Size(154, 85);
            this.groupBox18.TabIndex = 9;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Tallas";
            // 
            // cbxd56
            // 
            this.cbxd56.AutoSize = true;
            this.cbxd56.Location = new System.Drawing.Point(7, 65);
            this.cbxd56.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd56.Name = "cbxd56";
            this.cbxd56.Size = new System.Drawing.Size(40, 17);
            this.cbxd56.TabIndex = 6;
            this.cbxd56.Text = "27";
            this.cbxd56.UseVisualStyleBackColor = true;
            // 
            // cbxd55
            // 
            this.cbxd55.AutoSize = true;
            this.cbxd55.Location = new System.Drawing.Point(110, 42);
            this.cbxd55.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd55.Name = "cbxd55";
            this.cbxd55.Size = new System.Drawing.Size(40, 17);
            this.cbxd55.TabIndex = 5;
            this.cbxd55.Text = "26";
            this.cbxd55.UseVisualStyleBackColor = true;
            // 
            // cbxd54
            // 
            this.cbxd54.AutoSize = true;
            this.cbxd54.Location = new System.Drawing.Point(58, 42);
            this.cbxd54.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd54.Name = "cbxd54";
            this.cbxd54.Size = new System.Drawing.Size(40, 17);
            this.cbxd54.TabIndex = 4;
            this.cbxd54.Text = "25";
            this.cbxd54.UseVisualStyleBackColor = true;
            // 
            // cbxd53
            // 
            this.cbxd53.AutoSize = true;
            this.cbxd53.Location = new System.Drawing.Point(7, 42);
            this.cbxd53.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd53.Name = "cbxd53";
            this.cbxd53.Size = new System.Drawing.Size(40, 17);
            this.cbxd53.TabIndex = 3;
            this.cbxd53.Text = "24";
            this.cbxd53.UseVisualStyleBackColor = true;
            // 
            // cbxd52
            // 
            this.cbxd52.AutoSize = true;
            this.cbxd52.Location = new System.Drawing.Point(110, 19);
            this.cbxd52.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd52.Name = "cbxd52";
            this.cbxd52.Size = new System.Drawing.Size(40, 17);
            this.cbxd52.TabIndex = 2;
            this.cbxd52.Text = "23";
            this.cbxd52.UseVisualStyleBackColor = true;
            // 
            // cbxd51
            // 
            this.cbxd51.AutoSize = true;
            this.cbxd51.Location = new System.Drawing.Point(58, 19);
            this.cbxd51.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd51.Name = "cbxd51";
            this.cbxd51.Size = new System.Drawing.Size(40, 17);
            this.cbxd51.TabIndex = 1;
            this.cbxd51.Text = "22";
            this.cbxd51.UseVisualStyleBackColor = true;
            // 
            // cbxd50
            // 
            this.cbxd50.AutoSize = true;
            this.cbxd50.Location = new System.Drawing.Point(7, 19);
            this.cbxd50.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd50.Name = "cbxd50";
            this.cbxd50.Size = new System.Drawing.Size(40, 17);
            this.cbxd50.TabIndex = 0;
            this.cbxd50.Text = "21";
            this.cbxd50.UseVisualStyleBackColor = true;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox9.BackgroundImage")));
            this.pictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox9.Location = new System.Drawing.Point(6, 19);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(117, 81);
            this.pictureBox9.TabIndex = 0;
            this.pictureBox9.TabStop = false;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label20);
            this.groupBox10.Controls.Add(this.label19);
            this.groupBox10.Controls.Add(this.groupBox19);
            this.groupBox10.Controls.Add(this.pictureBox8);
            this.groupBox10.Location = new System.Drawing.Point(4, 455);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox10.Size = new System.Drawing.Size(401, 107);
            this.groupBox10.TabIndex = 9;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Zapatilla de punta";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(131, 61);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(79, 13);
            this.label20.TabIndex = 16;
            this.label20.Text = "Precio $ 700";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(131, 38);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(85, 13);
            this.label19.TabIndex = 14;
            this.label19.Text = "Color: Dorado";
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.cbxd63);
            this.groupBox19.Controls.Add(this.cbxd62);
            this.groupBox19.Controls.Add(this.cbxd61);
            this.groupBox19.Controls.Add(this.cbxd60);
            this.groupBox19.Controls.Add(this.cbxd59);
            this.groupBox19.Controls.Add(this.cbxd58);
            this.groupBox19.Controls.Add(this.cbxd57);
            this.groupBox19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox19.Location = new System.Drawing.Point(240, 15);
            this.groupBox19.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox19.Size = new System.Drawing.Size(154, 85);
            this.groupBox19.TabIndex = 9;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Tallas";
            // 
            // cbxd63
            // 
            this.cbxd63.AutoSize = true;
            this.cbxd63.Location = new System.Drawing.Point(7, 65);
            this.cbxd63.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd63.Name = "cbxd63";
            this.cbxd63.Size = new System.Drawing.Size(40, 17);
            this.cbxd63.TabIndex = 6;
            this.cbxd63.Text = "27";
            this.cbxd63.UseVisualStyleBackColor = true;
            // 
            // cbxd62
            // 
            this.cbxd62.AutoSize = true;
            this.cbxd62.Location = new System.Drawing.Point(110, 42);
            this.cbxd62.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd62.Name = "cbxd62";
            this.cbxd62.Size = new System.Drawing.Size(40, 17);
            this.cbxd62.TabIndex = 5;
            this.cbxd62.Text = "26";
            this.cbxd62.UseVisualStyleBackColor = true;
            // 
            // cbxd61
            // 
            this.cbxd61.AutoSize = true;
            this.cbxd61.Location = new System.Drawing.Point(58, 42);
            this.cbxd61.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd61.Name = "cbxd61";
            this.cbxd61.Size = new System.Drawing.Size(40, 17);
            this.cbxd61.TabIndex = 4;
            this.cbxd61.Text = "25";
            this.cbxd61.UseVisualStyleBackColor = true;
            // 
            // cbxd60
            // 
            this.cbxd60.AutoSize = true;
            this.cbxd60.Location = new System.Drawing.Point(7, 42);
            this.cbxd60.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd60.Name = "cbxd60";
            this.cbxd60.Size = new System.Drawing.Size(40, 17);
            this.cbxd60.TabIndex = 3;
            this.cbxd60.Text = "24";
            this.cbxd60.UseVisualStyleBackColor = true;
            // 
            // cbxd59
            // 
            this.cbxd59.AutoSize = true;
            this.cbxd59.Location = new System.Drawing.Point(110, 19);
            this.cbxd59.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd59.Name = "cbxd59";
            this.cbxd59.Size = new System.Drawing.Size(40, 17);
            this.cbxd59.TabIndex = 2;
            this.cbxd59.Text = "23";
            this.cbxd59.UseVisualStyleBackColor = true;
            // 
            // cbxd58
            // 
            this.cbxd58.AutoSize = true;
            this.cbxd58.Location = new System.Drawing.Point(58, 19);
            this.cbxd58.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd58.Name = "cbxd58";
            this.cbxd58.Size = new System.Drawing.Size(40, 17);
            this.cbxd58.TabIndex = 1;
            this.cbxd58.Text = "22";
            this.cbxd58.UseVisualStyleBackColor = true;
            // 
            // cbxd57
            // 
            this.cbxd57.AutoSize = true;
            this.cbxd57.Location = new System.Drawing.Point(7, 19);
            this.cbxd57.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd57.Name = "cbxd57";
            this.cbxd57.Size = new System.Drawing.Size(40, 17);
            this.cbxd57.TabIndex = 0;
            this.cbxd57.Text = "21";
            this.cbxd57.UseVisualStyleBackColor = true;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox8.BackgroundImage")));
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox8.Location = new System.Drawing.Point(6, 19);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(117, 81);
            this.pictureBox8.TabIndex = 0;
            this.pictureBox8.TabStop = false;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label14);
            this.groupBox9.Controls.Add(this.label13);
            this.groupBox9.Controls.Add(this.groupBox17);
            this.groupBox9.Controls.Add(this.pictureBox7);
            this.groupBox9.Location = new System.Drawing.Point(4, 342);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox9.Size = new System.Drawing.Size(401, 107);
            this.groupBox9.TabIndex = 8;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Zapatilla tacon de agúja";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(130, 62);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(79, 13);
            this.label14.TabIndex = 14;
            this.label14.Text = "Precio $ 600";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(130, 36);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(73, 13);
            this.label13.TabIndex = 13;
            this.label13.Text = "Color: Rosa";
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.cbxd49);
            this.groupBox17.Controls.Add(this.cbxd48);
            this.groupBox17.Controls.Add(this.cbxd47);
            this.groupBox17.Controls.Add(this.cbxd46);
            this.groupBox17.Controls.Add(this.cbxd45);
            this.groupBox17.Controls.Add(this.cbxd44);
            this.groupBox17.Controls.Add(this.cbxd43);
            this.groupBox17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox17.Location = new System.Drawing.Point(240, 16);
            this.groupBox17.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox17.Size = new System.Drawing.Size(154, 85);
            this.groupBox17.TabIndex = 9;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Tallas";
            // 
            // cbxd49
            // 
            this.cbxd49.AutoSize = true;
            this.cbxd49.Location = new System.Drawing.Point(7, 65);
            this.cbxd49.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd49.Name = "cbxd49";
            this.cbxd49.Size = new System.Drawing.Size(40, 17);
            this.cbxd49.TabIndex = 6;
            this.cbxd49.Text = "27";
            this.cbxd49.UseVisualStyleBackColor = true;
            // 
            // cbxd48
            // 
            this.cbxd48.AutoSize = true;
            this.cbxd48.Location = new System.Drawing.Point(110, 42);
            this.cbxd48.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd48.Name = "cbxd48";
            this.cbxd48.Size = new System.Drawing.Size(40, 17);
            this.cbxd48.TabIndex = 5;
            this.cbxd48.Text = "26";
            this.cbxd48.UseVisualStyleBackColor = true;
            // 
            // cbxd47
            // 
            this.cbxd47.AutoSize = true;
            this.cbxd47.Location = new System.Drawing.Point(58, 42);
            this.cbxd47.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd47.Name = "cbxd47";
            this.cbxd47.Size = new System.Drawing.Size(40, 17);
            this.cbxd47.TabIndex = 4;
            this.cbxd47.Text = "25";
            this.cbxd47.UseVisualStyleBackColor = true;
            // 
            // cbxd46
            // 
            this.cbxd46.AutoSize = true;
            this.cbxd46.Location = new System.Drawing.Point(7, 42);
            this.cbxd46.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd46.Name = "cbxd46";
            this.cbxd46.Size = new System.Drawing.Size(40, 17);
            this.cbxd46.TabIndex = 3;
            this.cbxd46.Text = "24";
            this.cbxd46.UseVisualStyleBackColor = true;
            // 
            // cbxd45
            // 
            this.cbxd45.AutoSize = true;
            this.cbxd45.Location = new System.Drawing.Point(110, 19);
            this.cbxd45.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd45.Name = "cbxd45";
            this.cbxd45.Size = new System.Drawing.Size(40, 17);
            this.cbxd45.TabIndex = 2;
            this.cbxd45.Text = "23";
            this.cbxd45.UseVisualStyleBackColor = true;
            // 
            // cbxd44
            // 
            this.cbxd44.AutoSize = true;
            this.cbxd44.Location = new System.Drawing.Point(58, 19);
            this.cbxd44.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd44.Name = "cbxd44";
            this.cbxd44.Size = new System.Drawing.Size(40, 17);
            this.cbxd44.TabIndex = 1;
            this.cbxd44.Text = "22";
            this.cbxd44.UseVisualStyleBackColor = true;
            // 
            // cbxd43
            // 
            this.cbxd43.AutoSize = true;
            this.cbxd43.Location = new System.Drawing.Point(7, 19);
            this.cbxd43.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd43.Name = "cbxd43";
            this.cbxd43.Size = new System.Drawing.Size(40, 17);
            this.cbxd43.TabIndex = 0;
            this.cbxd43.Text = "21";
            this.cbxd43.UseVisualStyleBackColor = true;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox7.BackgroundImage")));
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox7.Location = new System.Drawing.Point(6, 19);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(117, 81);
            this.pictureBox7.TabIndex = 0;
            this.pictureBox7.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.groupBox16);
            this.groupBox1.Controls.Add(this.pictureBox6);
            this.groupBox1.Location = new System.Drawing.Point(412, 229);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Size = new System.Drawing.Size(401, 107);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Zapatilla clasica";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(138, 61);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(79, 13);
            this.label10.TabIndex = 13;
            this.label10.Text = "Precio $ 750";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(133, 35);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 13);
            this.label9.TabIndex = 12;
            this.label9.Text = "Color: Blanco";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.cbxd42);
            this.groupBox16.Controls.Add(this.cbxd41);
            this.groupBox16.Controls.Add(this.cbxd40);
            this.groupBox16.Controls.Add(this.cbxd39);
            this.groupBox16.Controls.Add(this.cbxd38);
            this.groupBox16.Controls.Add(this.cbxd37);
            this.groupBox16.Controls.Add(this.cbxd36);
            this.groupBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox16.Location = new System.Drawing.Point(239, 16);
            this.groupBox16.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox16.Size = new System.Drawing.Size(154, 85);
            this.groupBox16.TabIndex = 9;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Tallas";
            // 
            // cbxd42
            // 
            this.cbxd42.AutoSize = true;
            this.cbxd42.Location = new System.Drawing.Point(7, 65);
            this.cbxd42.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd42.Name = "cbxd42";
            this.cbxd42.Size = new System.Drawing.Size(40, 17);
            this.cbxd42.TabIndex = 6;
            this.cbxd42.Text = "27";
            this.cbxd42.UseVisualStyleBackColor = true;
            // 
            // cbxd41
            // 
            this.cbxd41.AutoSize = true;
            this.cbxd41.Location = new System.Drawing.Point(110, 42);
            this.cbxd41.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd41.Name = "cbxd41";
            this.cbxd41.Size = new System.Drawing.Size(40, 17);
            this.cbxd41.TabIndex = 5;
            this.cbxd41.Text = "26";
            this.cbxd41.UseVisualStyleBackColor = true;
            // 
            // cbxd40
            // 
            this.cbxd40.AutoSize = true;
            this.cbxd40.Location = new System.Drawing.Point(58, 42);
            this.cbxd40.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd40.Name = "cbxd40";
            this.cbxd40.Size = new System.Drawing.Size(40, 17);
            this.cbxd40.TabIndex = 4;
            this.cbxd40.Text = "25";
            this.cbxd40.UseVisualStyleBackColor = true;
            // 
            // cbxd39
            // 
            this.cbxd39.AutoSize = true;
            this.cbxd39.Location = new System.Drawing.Point(7, 42);
            this.cbxd39.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd39.Name = "cbxd39";
            this.cbxd39.Size = new System.Drawing.Size(40, 17);
            this.cbxd39.TabIndex = 3;
            this.cbxd39.Text = "24";
            this.cbxd39.UseVisualStyleBackColor = true;
            // 
            // cbxd38
            // 
            this.cbxd38.AutoSize = true;
            this.cbxd38.Location = new System.Drawing.Point(110, 19);
            this.cbxd38.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd38.Name = "cbxd38";
            this.cbxd38.Size = new System.Drawing.Size(40, 17);
            this.cbxd38.TabIndex = 2;
            this.cbxd38.Text = "23";
            this.cbxd38.UseVisualStyleBackColor = true;
            // 
            // cbxd37
            // 
            this.cbxd37.AutoSize = true;
            this.cbxd37.Location = new System.Drawing.Point(58, 19);
            this.cbxd37.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd37.Name = "cbxd37";
            this.cbxd37.Size = new System.Drawing.Size(40, 17);
            this.cbxd37.TabIndex = 1;
            this.cbxd37.Text = "22";
            this.cbxd37.UseVisualStyleBackColor = true;
            // 
            // cbxd36
            // 
            this.cbxd36.AutoSize = true;
            this.cbxd36.Location = new System.Drawing.Point(7, 19);
            this.cbxd36.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd36.Name = "cbxd36";
            this.cbxd36.Size = new System.Drawing.Size(40, 17);
            this.cbxd36.TabIndex = 0;
            this.cbxd36.Text = "21";
            this.cbxd36.UseVisualStyleBackColor = true;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.BackgroundImage")));
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox6.Location = new System.Drawing.Point(6, 19);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(117, 81);
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label12);
            this.groupBox6.Controls.Add(this.label11);
            this.groupBox6.Controls.Add(this.groupBox15);
            this.groupBox6.Controls.Add(this.pictureBox5);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(4, 229);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox6.Size = new System.Drawing.Size(401, 107);
            this.groupBox6.TabIndex = 6;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Sandalia tacon de agúja";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(130, 34);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 13);
            this.label12.TabIndex = 14;
            this.label12.Text = "Color: Cafe";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(130, 62);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(79, 13);
            this.label11.TabIndex = 13;
            this.label11.Text = "Precio $ 500";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.cbxd35);
            this.groupBox15.Controls.Add(this.cbxd34);
            this.groupBox15.Controls.Add(this.cbxd33);
            this.groupBox15.Controls.Add(this.cbxd32);
            this.groupBox15.Controls.Add(this.cbxd31);
            this.groupBox15.Controls.Add(this.cbxd30);
            this.groupBox15.Controls.Add(this.cbxd29);
            this.groupBox15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox15.Location = new System.Drawing.Point(239, 15);
            this.groupBox15.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox15.Size = new System.Drawing.Size(154, 85);
            this.groupBox15.TabIndex = 9;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Tallas";
            // 
            // cbxd35
            // 
            this.cbxd35.AutoSize = true;
            this.cbxd35.Location = new System.Drawing.Point(7, 65);
            this.cbxd35.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd35.Name = "cbxd35";
            this.cbxd35.Size = new System.Drawing.Size(40, 17);
            this.cbxd35.TabIndex = 6;
            this.cbxd35.Text = "27";
            this.cbxd35.UseVisualStyleBackColor = true;
            // 
            // cbxd34
            // 
            this.cbxd34.AutoSize = true;
            this.cbxd34.Location = new System.Drawing.Point(110, 42);
            this.cbxd34.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd34.Name = "cbxd34";
            this.cbxd34.Size = new System.Drawing.Size(40, 17);
            this.cbxd34.TabIndex = 5;
            this.cbxd34.Text = "26";
            this.cbxd34.UseVisualStyleBackColor = true;
            // 
            // cbxd33
            // 
            this.cbxd33.AutoSize = true;
            this.cbxd33.Location = new System.Drawing.Point(58, 42);
            this.cbxd33.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd33.Name = "cbxd33";
            this.cbxd33.Size = new System.Drawing.Size(40, 17);
            this.cbxd33.TabIndex = 4;
            this.cbxd33.Text = "25";
            this.cbxd33.UseVisualStyleBackColor = true;
            // 
            // cbxd32
            // 
            this.cbxd32.AutoSize = true;
            this.cbxd32.Location = new System.Drawing.Point(7, 42);
            this.cbxd32.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd32.Name = "cbxd32";
            this.cbxd32.Size = new System.Drawing.Size(40, 17);
            this.cbxd32.TabIndex = 3;
            this.cbxd32.Text = "24";
            this.cbxd32.UseVisualStyleBackColor = true;
            // 
            // cbxd31
            // 
            this.cbxd31.AutoSize = true;
            this.cbxd31.Location = new System.Drawing.Point(110, 19);
            this.cbxd31.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd31.Name = "cbxd31";
            this.cbxd31.Size = new System.Drawing.Size(40, 17);
            this.cbxd31.TabIndex = 2;
            this.cbxd31.Text = "23";
            this.cbxd31.UseVisualStyleBackColor = true;
            // 
            // cbxd30
            // 
            this.cbxd30.AutoSize = true;
            this.cbxd30.Location = new System.Drawing.Point(58, 19);
            this.cbxd30.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd30.Name = "cbxd30";
            this.cbxd30.Size = new System.Drawing.Size(40, 17);
            this.cbxd30.TabIndex = 1;
            this.cbxd30.Text = "22";
            this.cbxd30.UseVisualStyleBackColor = true;
            // 
            // cbxd29
            // 
            this.cbxd29.AutoSize = true;
            this.cbxd29.Location = new System.Drawing.Point(7, 19);
            this.cbxd29.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd29.Name = "cbxd29";
            this.cbxd29.Size = new System.Drawing.Size(40, 17);
            this.cbxd29.TabIndex = 0;
            this.cbxd29.Text = "21";
            this.cbxd29.UseVisualStyleBackColor = true;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.BackgroundImage")));
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Location = new System.Drawing.Point(6, 19);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(117, 81);
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.groupBox14);
            this.groupBox5.Controls.Add(this.pictureBox4);
            this.groupBox5.Location = new System.Drawing.Point(412, 116);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox5.Size = new System.Drawing.Size(401, 107);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Zapatilla ejecutiva";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(140, 62);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "Precio $ 350";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(133, 35);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(78, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Color: Negro";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.cbxd28);
            this.groupBox14.Controls.Add(this.cbxd27);
            this.groupBox14.Controls.Add(this.cbxd26);
            this.groupBox14.Controls.Add(this.cbxd25);
            this.groupBox14.Controls.Add(this.cbxd24);
            this.groupBox14.Controls.Add(this.cbxd23);
            this.groupBox14.Controls.Add(this.cbxd22);
            this.groupBox14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox14.Location = new System.Drawing.Point(239, 16);
            this.groupBox14.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox14.Size = new System.Drawing.Size(154, 85);
            this.groupBox14.TabIndex = 9;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Tallas";
            // 
            // cbxd28
            // 
            this.cbxd28.AutoSize = true;
            this.cbxd28.Location = new System.Drawing.Point(7, 65);
            this.cbxd28.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd28.Name = "cbxd28";
            this.cbxd28.Size = new System.Drawing.Size(40, 17);
            this.cbxd28.TabIndex = 6;
            this.cbxd28.Text = "27";
            this.cbxd28.UseVisualStyleBackColor = true;
            // 
            // cbxd27
            // 
            this.cbxd27.AutoSize = true;
            this.cbxd27.Location = new System.Drawing.Point(110, 42);
            this.cbxd27.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd27.Name = "cbxd27";
            this.cbxd27.Size = new System.Drawing.Size(40, 17);
            this.cbxd27.TabIndex = 5;
            this.cbxd27.Text = "26";
            this.cbxd27.UseVisualStyleBackColor = true;
            // 
            // cbxd26
            // 
            this.cbxd26.AutoSize = true;
            this.cbxd26.Location = new System.Drawing.Point(58, 42);
            this.cbxd26.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd26.Name = "cbxd26";
            this.cbxd26.Size = new System.Drawing.Size(40, 17);
            this.cbxd26.TabIndex = 4;
            this.cbxd26.Text = "25";
            this.cbxd26.UseVisualStyleBackColor = true;
            // 
            // cbxd25
            // 
            this.cbxd25.AutoSize = true;
            this.cbxd25.Location = new System.Drawing.Point(7, 42);
            this.cbxd25.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd25.Name = "cbxd25";
            this.cbxd25.Size = new System.Drawing.Size(40, 17);
            this.cbxd25.TabIndex = 3;
            this.cbxd25.Text = "24";
            this.cbxd25.UseVisualStyleBackColor = true;
            // 
            // cbxd24
            // 
            this.cbxd24.AutoSize = true;
            this.cbxd24.Location = new System.Drawing.Point(110, 19);
            this.cbxd24.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd24.Name = "cbxd24";
            this.cbxd24.Size = new System.Drawing.Size(40, 17);
            this.cbxd24.TabIndex = 2;
            this.cbxd24.Text = "23";
            this.cbxd24.UseVisualStyleBackColor = true;
            // 
            // cbxd23
            // 
            this.cbxd23.AutoSize = true;
            this.cbxd23.Location = new System.Drawing.Point(58, 19);
            this.cbxd23.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd23.Name = "cbxd23";
            this.cbxd23.Size = new System.Drawing.Size(40, 17);
            this.cbxd23.TabIndex = 1;
            this.cbxd23.Text = "22";
            this.cbxd23.UseVisualStyleBackColor = true;
            // 
            // cbxd22
            // 
            this.cbxd22.AutoSize = true;
            this.cbxd22.Location = new System.Drawing.Point(7, 19);
            this.cbxd22.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd22.Name = "cbxd22";
            this.cbxd22.Size = new System.Drawing.Size(40, 17);
            this.cbxd22.TabIndex = 0;
            this.cbxd22.Text = "21";
            this.cbxd22.UseVisualStyleBackColor = true;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Location = new System.Drawing.Point(7, 19);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(117, 81);
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.groupBox13);
            this.groupBox4.Controls.Add(this.pictureBox3);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(4, 116);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox4.Size = new System.Drawing.Size(401, 107);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Zapatilla c/ plataforma pulsera ajustable";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(122, 65);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Precio $ 350";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(122, 39);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Color: Azul claro";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.cbxd21);
            this.groupBox13.Controls.Add(this.cbxd20);
            this.groupBox13.Controls.Add(this.cbxd19);
            this.groupBox13.Controls.Add(this.cbxd18);
            this.groupBox13.Controls.Add(this.cbxd17);
            this.groupBox13.Controls.Add(this.cbxd16);
            this.groupBox13.Controls.Add(this.cbxd15);
            this.groupBox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox13.Location = new System.Drawing.Point(239, 19);
            this.groupBox13.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox13.Size = new System.Drawing.Size(154, 85);
            this.groupBox13.TabIndex = 9;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Tallas";
            // 
            // cbxd21
            // 
            this.cbxd21.AutoSize = true;
            this.cbxd21.Location = new System.Drawing.Point(7, 65);
            this.cbxd21.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd21.Name = "cbxd21";
            this.cbxd21.Size = new System.Drawing.Size(40, 17);
            this.cbxd21.TabIndex = 6;
            this.cbxd21.Text = "27";
            this.cbxd21.UseVisualStyleBackColor = true;
            // 
            // cbxd20
            // 
            this.cbxd20.AutoSize = true;
            this.cbxd20.Location = new System.Drawing.Point(110, 42);
            this.cbxd20.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd20.Name = "cbxd20";
            this.cbxd20.Size = new System.Drawing.Size(40, 17);
            this.cbxd20.TabIndex = 5;
            this.cbxd20.Text = "26";
            this.cbxd20.UseVisualStyleBackColor = true;
            // 
            // cbxd19
            // 
            this.cbxd19.AutoSize = true;
            this.cbxd19.Location = new System.Drawing.Point(58, 42);
            this.cbxd19.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd19.Name = "cbxd19";
            this.cbxd19.Size = new System.Drawing.Size(40, 17);
            this.cbxd19.TabIndex = 4;
            this.cbxd19.Text = "25";
            this.cbxd19.UseVisualStyleBackColor = true;
            // 
            // cbxd18
            // 
            this.cbxd18.AutoSize = true;
            this.cbxd18.Location = new System.Drawing.Point(7, 42);
            this.cbxd18.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd18.Name = "cbxd18";
            this.cbxd18.Size = new System.Drawing.Size(40, 17);
            this.cbxd18.TabIndex = 3;
            this.cbxd18.Text = "24";
            this.cbxd18.UseVisualStyleBackColor = true;
            // 
            // cbxd17
            // 
            this.cbxd17.AutoSize = true;
            this.cbxd17.Location = new System.Drawing.Point(110, 19);
            this.cbxd17.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd17.Name = "cbxd17";
            this.cbxd17.Size = new System.Drawing.Size(40, 17);
            this.cbxd17.TabIndex = 2;
            this.cbxd17.Text = "23";
            this.cbxd17.UseVisualStyleBackColor = true;
            // 
            // cbxd16
            // 
            this.cbxd16.AutoSize = true;
            this.cbxd16.Location = new System.Drawing.Point(58, 19);
            this.cbxd16.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd16.Name = "cbxd16";
            this.cbxd16.Size = new System.Drawing.Size(40, 17);
            this.cbxd16.TabIndex = 1;
            this.cbxd16.Text = "22";
            this.cbxd16.UseVisualStyleBackColor = true;
            // 
            // cbxd15
            // 
            this.cbxd15.AutoSize = true;
            this.cbxd15.Location = new System.Drawing.Point(7, 19);
            this.cbxd15.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd15.Name = "cbxd15";
            this.cbxd15.Size = new System.Drawing.Size(40, 17);
            this.cbxd15.TabIndex = 0;
            this.cbxd15.Text = "21";
            this.cbxd15.UseVisualStyleBackColor = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(6, 19);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(117, 81);
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.groupBox8);
            this.groupBox3.Controls.Add(this.pictureBox2);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(412, 3);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox3.Size = new System.Drawing.Size(401, 107);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Zapatilla clasica";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(127, 68);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Precio $ 400";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(127, 39);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Color: Negro";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.cbxd14);
            this.groupBox8.Controls.Add(this.cbxd13);
            this.groupBox8.Controls.Add(this.cbxd12);
            this.groupBox8.Controls.Add(this.cbxd11);
            this.groupBox8.Controls.Add(this.cbxd10);
            this.groupBox8.Controls.Add(this.cbxd9);
            this.groupBox8.Controls.Add(this.cbxd8);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(239, 16);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox8.Size = new System.Drawing.Size(154, 85);
            this.groupBox8.TabIndex = 8;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Tallas";
            // 
            // cbxd14
            // 
            this.cbxd14.AutoSize = true;
            this.cbxd14.Location = new System.Drawing.Point(7, 65);
            this.cbxd14.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd14.Name = "cbxd14";
            this.cbxd14.Size = new System.Drawing.Size(40, 17);
            this.cbxd14.TabIndex = 6;
            this.cbxd14.Text = "27";
            this.cbxd14.UseVisualStyleBackColor = true;
            // 
            // cbxd13
            // 
            this.cbxd13.AutoSize = true;
            this.cbxd13.Location = new System.Drawing.Point(110, 42);
            this.cbxd13.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd13.Name = "cbxd13";
            this.cbxd13.Size = new System.Drawing.Size(40, 17);
            this.cbxd13.TabIndex = 5;
            this.cbxd13.Text = "26";
            this.cbxd13.UseVisualStyleBackColor = true;
            // 
            // cbxd12
            // 
            this.cbxd12.AutoSize = true;
            this.cbxd12.Location = new System.Drawing.Point(58, 42);
            this.cbxd12.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd12.Name = "cbxd12";
            this.cbxd12.Size = new System.Drawing.Size(40, 17);
            this.cbxd12.TabIndex = 4;
            this.cbxd12.Text = "25";
            this.cbxd12.UseVisualStyleBackColor = true;
            // 
            // cbxd11
            // 
            this.cbxd11.AutoSize = true;
            this.cbxd11.Location = new System.Drawing.Point(7, 42);
            this.cbxd11.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd11.Name = "cbxd11";
            this.cbxd11.Size = new System.Drawing.Size(40, 17);
            this.cbxd11.TabIndex = 3;
            this.cbxd11.Text = "24";
            this.cbxd11.UseVisualStyleBackColor = true;
            // 
            // cbxd10
            // 
            this.cbxd10.AutoSize = true;
            this.cbxd10.Location = new System.Drawing.Point(110, 19);
            this.cbxd10.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd10.Name = "cbxd10";
            this.cbxd10.Size = new System.Drawing.Size(40, 17);
            this.cbxd10.TabIndex = 2;
            this.cbxd10.Text = "23";
            this.cbxd10.UseVisualStyleBackColor = true;
            // 
            // cbxd9
            // 
            this.cbxd9.AutoSize = true;
            this.cbxd9.Location = new System.Drawing.Point(58, 19);
            this.cbxd9.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd9.Name = "cbxd9";
            this.cbxd9.Size = new System.Drawing.Size(40, 17);
            this.cbxd9.TabIndex = 1;
            this.cbxd9.Text = "22";
            this.cbxd9.UseVisualStyleBackColor = true;
            // 
            // cbxd8
            // 
            this.cbxd8.AutoSize = true;
            this.cbxd8.Location = new System.Drawing.Point(7, 19);
            this.cbxd8.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd8.Name = "cbxd8";
            this.cbxd8.Size = new System.Drawing.Size(40, 17);
            this.cbxd8.TabIndex = 0;
            this.cbxd8.Text = "21";
            this.cbxd8.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(7, 19);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(113, 82);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.groupBox7);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(4, 3);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox2.Size = new System.Drawing.Size(401, 107);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Sandalia c/ pulsera";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(124, 35);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Color: Negro";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(124, 68);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Precio $ 300";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.cbxd7);
            this.groupBox7.Controls.Add(this.cbxd6);
            this.groupBox7.Controls.Add(this.cbxd5);
            this.groupBox7.Controls.Add(this.cbxd4);
            this.groupBox7.Controls.Add(this.cbxd3);
            this.groupBox7.Controls.Add(this.cbxd2);
            this.groupBox7.Controls.Add(this.cbxd1);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(239, 16);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox7.Size = new System.Drawing.Size(154, 85);
            this.groupBox7.TabIndex = 7;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Tallas";
            // 
            // cbxd7
            // 
            this.cbxd7.AutoSize = true;
            this.cbxd7.Location = new System.Drawing.Point(7, 65);
            this.cbxd7.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd7.Name = "cbxd7";
            this.cbxd7.Size = new System.Drawing.Size(40, 17);
            this.cbxd7.TabIndex = 6;
            this.cbxd7.Text = "27";
            this.cbxd7.UseVisualStyleBackColor = true;
            // 
            // cbxd6
            // 
            this.cbxd6.AutoSize = true;
            this.cbxd6.Location = new System.Drawing.Point(110, 42);
            this.cbxd6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd6.Name = "cbxd6";
            this.cbxd6.Size = new System.Drawing.Size(40, 17);
            this.cbxd6.TabIndex = 5;
            this.cbxd6.Text = "26";
            this.cbxd6.UseVisualStyleBackColor = true;
            // 
            // cbxd5
            // 
            this.cbxd5.AutoSize = true;
            this.cbxd5.Location = new System.Drawing.Point(58, 42);
            this.cbxd5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd5.Name = "cbxd5";
            this.cbxd5.Size = new System.Drawing.Size(40, 17);
            this.cbxd5.TabIndex = 4;
            this.cbxd5.Text = "25";
            this.cbxd5.UseVisualStyleBackColor = true;
            // 
            // cbxd4
            // 
            this.cbxd4.AutoSize = true;
            this.cbxd4.Location = new System.Drawing.Point(7, 42);
            this.cbxd4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd4.Name = "cbxd4";
            this.cbxd4.Size = new System.Drawing.Size(40, 17);
            this.cbxd4.TabIndex = 3;
            this.cbxd4.Text = "24";
            this.cbxd4.UseVisualStyleBackColor = true;
            // 
            // cbxd3
            // 
            this.cbxd3.AutoSize = true;
            this.cbxd3.Location = new System.Drawing.Point(110, 19);
            this.cbxd3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd3.Name = "cbxd3";
            this.cbxd3.Size = new System.Drawing.Size(40, 17);
            this.cbxd3.TabIndex = 2;
            this.cbxd3.Text = "23";
            this.cbxd3.UseVisualStyleBackColor = true;
            // 
            // cbxd2
            // 
            this.cbxd2.AutoSize = true;
            this.cbxd2.Location = new System.Drawing.Point(58, 19);
            this.cbxd2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd2.Name = "cbxd2";
            this.cbxd2.Size = new System.Drawing.Size(40, 17);
            this.cbxd2.TabIndex = 1;
            this.cbxd2.Text = "22";
            this.cbxd2.UseVisualStyleBackColor = true;
            // 
            // cbxd1
            // 
            this.cbxd1.AutoSize = true;
            this.cbxd1.Location = new System.Drawing.Point(7, 19);
            this.cbxd1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbxd1.Name = "cbxd1";
            this.cbxd1.Size = new System.Drawing.Size(40, 17);
            this.cbxd1.TabIndex = 0;
            this.cbxd1.Text = "21";
            this.cbxd1.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(7, 16);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(117, 81);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // frmProddamas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(863, 468);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnregresar);
            this.Controls.Add(this.btnagregar);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "frmProddamas";
            this.Text = "Productos Damas";
            this.panel1.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnagregar;
        private System.Windows.Forms.Button btnregresar;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.CheckBox cbxd7;
        private System.Windows.Forms.CheckBox cbxd6;
        private System.Windows.Forms.CheckBox cbxd5;
        private System.Windows.Forms.CheckBox cbxd4;
        private System.Windows.Forms.CheckBox cbxd3;
        private System.Windows.Forms.CheckBox cbxd2;
        private System.Windows.Forms.CheckBox cbxd1;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.CheckBox cbxd14;
        private System.Windows.Forms.CheckBox cbxd13;
        private System.Windows.Forms.CheckBox cbxd12;
        private System.Windows.Forms.CheckBox cbxd11;
        private System.Windows.Forms.CheckBox cbxd10;
        private System.Windows.Forms.CheckBox cbxd9;
        private System.Windows.Forms.CheckBox cbxd8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.CheckBox cbxd70;
        private System.Windows.Forms.CheckBox cbxd69;
        private System.Windows.Forms.CheckBox cbxd68;
        private System.Windows.Forms.CheckBox cbxd67;
        private System.Windows.Forms.CheckBox cbxd66;
        private System.Windows.Forms.CheckBox cbxd65;
        private System.Windows.Forms.CheckBox cbxd64;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.CheckBox cbxd56;
        private System.Windows.Forms.CheckBox cbxd55;
        private System.Windows.Forms.CheckBox cbxd54;
        private System.Windows.Forms.CheckBox cbxd53;
        private System.Windows.Forms.CheckBox cbxd52;
        private System.Windows.Forms.CheckBox cbxd51;
        private System.Windows.Forms.CheckBox cbxd50;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.CheckBox cbxd63;
        private System.Windows.Forms.CheckBox cbxd62;
        private System.Windows.Forms.CheckBox cbxd61;
        private System.Windows.Forms.CheckBox cbxd60;
        private System.Windows.Forms.CheckBox cbxd59;
        private System.Windows.Forms.CheckBox cbxd58;
        private System.Windows.Forms.CheckBox cbxd57;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.CheckBox cbxd49;
        private System.Windows.Forms.CheckBox cbxd48;
        private System.Windows.Forms.CheckBox cbxd47;
        private System.Windows.Forms.CheckBox cbxd46;
        private System.Windows.Forms.CheckBox cbxd45;
        private System.Windows.Forms.CheckBox cbxd44;
        private System.Windows.Forms.CheckBox cbxd43;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.CheckBox cbxd42;
        private System.Windows.Forms.CheckBox cbxd41;
        private System.Windows.Forms.CheckBox cbxd40;
        private System.Windows.Forms.CheckBox cbxd39;
        private System.Windows.Forms.CheckBox cbxd38;
        private System.Windows.Forms.CheckBox cbxd37;
        private System.Windows.Forms.CheckBox cbxd36;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.CheckBox cbxd35;
        private System.Windows.Forms.CheckBox cbxd34;
        private System.Windows.Forms.CheckBox cbxd33;
        private System.Windows.Forms.CheckBox cbxd32;
        private System.Windows.Forms.CheckBox cbxd31;
        private System.Windows.Forms.CheckBox cbxd30;
        private System.Windows.Forms.CheckBox cbxd29;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.CheckBox cbxd28;
        private System.Windows.Forms.CheckBox cbxd27;
        private System.Windows.Forms.CheckBox cbxd26;
        private System.Windows.Forms.CheckBox cbxd25;
        private System.Windows.Forms.CheckBox cbxd24;
        private System.Windows.Forms.CheckBox cbxd23;
        private System.Windows.Forms.CheckBox cbxd22;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.CheckBox cbxd21;
        private System.Windows.Forms.CheckBox cbxd20;
        private System.Windows.Forms.CheckBox cbxd19;
        private System.Windows.Forms.CheckBox cbxd18;
        private System.Windows.Forms.CheckBox cbxd17;
        private System.Windows.Forms.CheckBox cbxd16;
        private System.Windows.Forms.CheckBox cbxd15;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
    }
}