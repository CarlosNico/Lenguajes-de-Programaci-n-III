﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace CRUD.Formularios
{
    public partial class frmRegproveedor : Form
    {
        public frmRegproveedor()
        {
            InitializeComponent();
        }

        private void btnagregar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=DESKTOP-5AVHSPI\\SQLEXPRESS;Initial Catalog=ZapateriaUmi;Integrated Security=True;Encrypt=False"))
            {
                if (txtnombre.Text == "" | txtdireccion.Text == "")
                {
                    MessageBox.Show("Por favor llenar todos los campos de campos");
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("INSERT into PROVEEDOR (nombre, direccion) values ('" + txtnombre.Text + "','" + txtdireccion.Text + "')", cn);
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Se agrego exitosamente al proveedor " + txtnombre.Text + ".");
                    txtnombre.Clear();
                    txtdireccion.Clear();
                }
            }
        }

        private void btnmodificar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=DESKTOP-5AVHSPI\\SQLEXPRESS;Initial Catalog=ZapateriaUmi;Integrated Security=True;Encrypt=False"))
            {
                if (txtnombre.Text == "" | txtdireccion.Text == "")
                {
                    MessageBox.Show("Por favor llenar todos los campos de campos");
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("UPDATE PROVEEDOR set nombre = '" + txtnombre.Text + "', direccion = '" + txtdireccion.Text + "' where nif = '" + txtnif.Text + "'", cn);
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Se modifico exitosamente al proveedor " + txtnombre.Text + ".");
                    txtnombre.Clear();
                    txtdireccion.Clear();
                    txtnif.Clear();
                }
            }
        }

        private void btneliminar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=DESKTOP-5AVHSPI\\SQLEXPRESS;Initial Catalog=ZapateriaUmi;Integrated Security=True;Encrypt=False"))
            {
                    SqlCommand cmd = new SqlCommand("DELETE from PROVEEDOR where nif = '" + txtnif.Text + "'", cn);
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Se elimino exitosamente al proveedor");
                txtnif.Clear();
            }
            }

        private void btnmostrar_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlConnection cn = new SqlConnection("Data Source=DESKTOP-5AVHSPI\\SQLEXPRESS;Initial Catalog=ZapateriaUmi;Integrated Security=True;Encrypt=False"))
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * from PROVEEDOR", cn);
                da.SelectCommand.CommandType = CommandType.Text;
                cn.Open();
                da.Fill(dt);
                dgvproveedor.DataSource = dt;
            }
        }

        private void btnregresar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}

