﻿namespace CRUD.Formularios
{
    partial class frmProdcaballeros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProdcaballeros));
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.cbxc7 = new System.Windows.Forms.CheckBox();
            this.cbxc6 = new System.Windows.Forms.CheckBox();
            this.cbxc5 = new System.Windows.Forms.CheckBox();
            this.cbxc4 = new System.Windows.Forms.CheckBox();
            this.cbxc3 = new System.Windows.Forms.CheckBox();
            this.cbxc2 = new System.Windows.Forms.CheckBox();
            this.cbxc1 = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnagregar = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.cbxc69 = new System.Windows.Forms.CheckBox();
            this.cbxc68 = new System.Windows.Forms.CheckBox();
            this.cbxc67 = new System.Windows.Forms.CheckBox();
            this.cbxc66 = new System.Windows.Forms.CheckBox();
            this.cbxc65 = new System.Windows.Forms.CheckBox();
            this.cbxc64 = new System.Windows.Forms.CheckBox();
            this.cbxc63 = new System.Windows.Forms.CheckBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.cbxc62 = new System.Windows.Forms.CheckBox();
            this.cbxc61 = new System.Windows.Forms.CheckBox();
            this.cbxc60 = new System.Windows.Forms.CheckBox();
            this.cbxc59 = new System.Windows.Forms.CheckBox();
            this.cbxc58 = new System.Windows.Forms.CheckBox();
            this.cbxc57 = new System.Windows.Forms.CheckBox();
            this.cbxc56 = new System.Windows.Forms.CheckBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.cbxc55 = new System.Windows.Forms.CheckBox();
            this.cbxc54 = new System.Windows.Forms.CheckBox();
            this.cbxc53 = new System.Windows.Forms.CheckBox();
            this.cbxc52 = new System.Windows.Forms.CheckBox();
            this.cbxc51 = new System.Windows.Forms.CheckBox();
            this.cbxc50 = new System.Windows.Forms.CheckBox();
            this.cbxc49 = new System.Windows.Forms.CheckBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.cbxc70 = new System.Windows.Forms.CheckBox();
            this.cbxc48 = new System.Windows.Forms.CheckBox();
            this.cbxc47 = new System.Windows.Forms.CheckBox();
            this.cbxc46 = new System.Windows.Forms.CheckBox();
            this.cbxc45 = new System.Windows.Forms.CheckBox();
            this.cbxc44 = new System.Windows.Forms.CheckBox();
            this.cbxc43 = new System.Windows.Forms.CheckBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.cbxc42 = new System.Windows.Forms.CheckBox();
            this.cbxc41 = new System.Windows.Forms.CheckBox();
            this.cbxc40 = new System.Windows.Forms.CheckBox();
            this.cbxc39 = new System.Windows.Forms.CheckBox();
            this.cbxc38 = new System.Windows.Forms.CheckBox();
            this.cbxc37 = new System.Windows.Forms.CheckBox();
            this.cbxc36 = new System.Windows.Forms.CheckBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.cbxc35 = new System.Windows.Forms.CheckBox();
            this.cbxc34 = new System.Windows.Forms.CheckBox();
            this.cbxc33 = new System.Windows.Forms.CheckBox();
            this.cbxc32 = new System.Windows.Forms.CheckBox();
            this.cbxc31 = new System.Windows.Forms.CheckBox();
            this.cbxc30 = new System.Windows.Forms.CheckBox();
            this.cbxc29 = new System.Windows.Forms.CheckBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.cbxc28 = new System.Windows.Forms.CheckBox();
            this.cbxc27 = new System.Windows.Forms.CheckBox();
            this.cbxc26 = new System.Windows.Forms.CheckBox();
            this.cbxc25 = new System.Windows.Forms.CheckBox();
            this.cbxc24 = new System.Windows.Forms.CheckBox();
            this.cbxc23 = new System.Windows.Forms.CheckBox();
            this.cbxc22 = new System.Windows.Forms.CheckBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.cbxc21 = new System.Windows.Forms.CheckBox();
            this.cbxc20 = new System.Windows.Forms.CheckBox();
            this.cbxc19 = new System.Windows.Forms.CheckBox();
            this.cbxc18 = new System.Windows.Forms.CheckBox();
            this.cbxc17 = new System.Windows.Forms.CheckBox();
            this.cbxc16 = new System.Windows.Forms.CheckBox();
            this.cbxc15 = new System.Windows.Forms.CheckBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbxc14 = new System.Windows.Forms.CheckBox();
            this.cbxc13 = new System.Windows.Forms.CheckBox();
            this.cbxc12 = new System.Windows.Forms.CheckBox();
            this.cbxc11 = new System.Windows.Forms.CheckBox();
            this.cbxc10 = new System.Windows.Forms.CheckBox();
            this.cbxc9 = new System.Windows.Forms.CheckBox();
            this.cbxc8 = new System.Windows.Forms.CheckBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnregresar = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.groupBox17.SuspendLayout();
            this.groupBox18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.groupBox15.SuspendLayout();
            this.groupBox16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.groupBox13.SuspendLayout();
            this.groupBox14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.groupBox11.SuspendLayout();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(6, 65);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(38, 17);
            this.checkBox1.TabIndex = 6;
            this.checkBox1.Text = "27";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(94, 42);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(38, 17);
            this.checkBox8.TabIndex = 5;
            this.checkBox8.Text = "26";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(50, 42);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(38, 17);
            this.checkBox9.TabIndex = 4;
            this.checkBox9.Text = "25";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(6, 42);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(38, 17);
            this.checkBox10.TabIndex = 3;
            this.checkBox10.Text = "24";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(94, 19);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(38, 17);
            this.checkBox11.TabIndex = 2;
            this.checkBox11.Text = "23";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Location = new System.Drawing.Point(50, 19);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(38, 17);
            this.checkBox12.TabIndex = 1;
            this.checkBox12.Text = "22";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Location = new System.Drawing.Point(6, 19);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(38, 17);
            this.checkBox13.TabIndex = 0;
            this.checkBox13.Text = "21";
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.groupBox7);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(3, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(404, 107);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Botin con elastico";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(112, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Color: Negro";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(112, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Precio $ 400";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.cbxc7);
            this.groupBox7.Controls.Add(this.cbxc6);
            this.groupBox7.Controls.Add(this.cbxc5);
            this.groupBox7.Controls.Add(this.cbxc4);
            this.groupBox7.Controls.Add(this.cbxc3);
            this.groupBox7.Controls.Add(this.cbxc2);
            this.groupBox7.Controls.Add(this.cbxc1);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(255, 13);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(132, 85);
            this.groupBox7.TabIndex = 7;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Tallas";
            // 
            // cbxc7
            // 
            this.cbxc7.AutoSize = true;
            this.cbxc7.Location = new System.Drawing.Point(6, 65);
            this.cbxc7.Name = "cbxc7";
            this.cbxc7.Size = new System.Drawing.Size(40, 17);
            this.cbxc7.TabIndex = 6;
            this.cbxc7.Text = "27";
            this.cbxc7.UseVisualStyleBackColor = true;
            // 
            // cbxc6
            // 
            this.cbxc6.AutoSize = true;
            this.cbxc6.Location = new System.Drawing.Point(94, 42);
            this.cbxc6.Name = "cbxc6";
            this.cbxc6.Size = new System.Drawing.Size(40, 17);
            this.cbxc6.TabIndex = 5;
            this.cbxc6.Text = "26";
            this.cbxc6.UseVisualStyleBackColor = true;
            // 
            // cbxc5
            // 
            this.cbxc5.AutoSize = true;
            this.cbxc5.Location = new System.Drawing.Point(50, 42);
            this.cbxc5.Name = "cbxc5";
            this.cbxc5.Size = new System.Drawing.Size(40, 17);
            this.cbxc5.TabIndex = 4;
            this.cbxc5.Text = "25";
            this.cbxc5.UseVisualStyleBackColor = true;
            // 
            // cbxc4
            // 
            this.cbxc4.AutoSize = true;
            this.cbxc4.Location = new System.Drawing.Point(6, 42);
            this.cbxc4.Name = "cbxc4";
            this.cbxc4.Size = new System.Drawing.Size(40, 17);
            this.cbxc4.TabIndex = 3;
            this.cbxc4.Text = "24";
            this.cbxc4.UseVisualStyleBackColor = true;
            // 
            // cbxc3
            // 
            this.cbxc3.AutoSize = true;
            this.cbxc3.Location = new System.Drawing.Point(94, 19);
            this.cbxc3.Name = "cbxc3";
            this.cbxc3.Size = new System.Drawing.Size(40, 17);
            this.cbxc3.TabIndex = 2;
            this.cbxc3.Text = "23";
            this.cbxc3.UseVisualStyleBackColor = true;
            // 
            // cbxc2
            // 
            this.cbxc2.AutoSize = true;
            this.cbxc2.Location = new System.Drawing.Point(50, 19);
            this.cbxc2.Name = "cbxc2";
            this.cbxc2.Size = new System.Drawing.Size(40, 17);
            this.cbxc2.TabIndex = 1;
            this.cbxc2.Text = "22";
            this.cbxc2.UseVisualStyleBackColor = true;
            // 
            // cbxc1
            // 
            this.cbxc1.AutoSize = true;
            this.cbxc1.Location = new System.Drawing.Point(6, 19);
            this.cbxc1.Name = "cbxc1";
            this.cbxc1.Size = new System.Drawing.Size(40, 17);
            this.cbxc1.TabIndex = 0;
            this.cbxc1.Text = "21";
            this.cbxc1.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(6, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 81);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnagregar
            // 
            this.btnagregar.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.btnagregar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnagregar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnagregar.Location = new System.Drawing.Point(119, 389);
            this.btnagregar.Name = "btnagregar";
            this.btnagregar.Size = new System.Drawing.Size(145, 36);
            this.btnagregar.TabIndex = 0;
            this.btnagregar.Text = "Agregar";
            this.btnagregar.UseVisualStyleBackColor = false;
            this.btnagregar.Click += new System.EventHandler(this.btnagregar_Click);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.groupBox19);
            this.panel1.Controls.Add(this.groupBox17);
            this.panel1.Controls.Add(this.groupBox15);
            this.panel1.Controls.Add(this.groupBox13);
            this.panel1.Controls.Add(this.groupBox11);
            this.panel1.Controls.Add(this.groupBox9);
            this.panel1.Controls.Add(this.groupBox6);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Location = new System.Drawing.Point(12, 8);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(849, 326);
            this.panel1.TabIndex = 6;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.label19);
            this.groupBox19.Controls.Add(this.label20);
            this.groupBox19.Controls.Add(this.groupBox20);
            this.groupBox19.Controls.Add(this.pictureBox10);
            this.groupBox19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox19.Location = new System.Drawing.Point(413, 438);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(416, 107);
            this.groupBox19.TabIndex = 11;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Bota vaquera";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(112, 36);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(70, 13);
            this.label19.TabIndex = 9;
            this.label19.Text = "Color: Cafe";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(112, 68);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(86, 13);
            this.label20.TabIndex = 8;
            this.label20.Text = "Precio $ 1000";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.cbxc69);
            this.groupBox20.Controls.Add(this.cbxc68);
            this.groupBox20.Controls.Add(this.cbxc67);
            this.groupBox20.Controls.Add(this.cbxc66);
            this.groupBox20.Controls.Add(this.cbxc65);
            this.groupBox20.Controls.Add(this.cbxc64);
            this.groupBox20.Controls.Add(this.cbxc63);
            this.groupBox20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox20.Location = new System.Drawing.Point(278, 16);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(132, 85);
            this.groupBox20.TabIndex = 7;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Tallas";
            // 
            // cbxc69
            // 
            this.cbxc69.AutoSize = true;
            this.cbxc69.Location = new System.Drawing.Point(6, 65);
            this.cbxc69.Name = "cbxc69";
            this.cbxc69.Size = new System.Drawing.Size(40, 17);
            this.cbxc69.TabIndex = 6;
            this.cbxc69.Text = "27";
            this.cbxc69.UseVisualStyleBackColor = true;
            // 
            // cbxc68
            // 
            this.cbxc68.AutoSize = true;
            this.cbxc68.Location = new System.Drawing.Point(94, 42);
            this.cbxc68.Name = "cbxc68";
            this.cbxc68.Size = new System.Drawing.Size(40, 17);
            this.cbxc68.TabIndex = 5;
            this.cbxc68.Text = "26";
            this.cbxc68.UseVisualStyleBackColor = true;
            // 
            // cbxc67
            // 
            this.cbxc67.AutoSize = true;
            this.cbxc67.Location = new System.Drawing.Point(50, 42);
            this.cbxc67.Name = "cbxc67";
            this.cbxc67.Size = new System.Drawing.Size(40, 17);
            this.cbxc67.TabIndex = 4;
            this.cbxc67.Text = "25";
            this.cbxc67.UseVisualStyleBackColor = true;
            // 
            // cbxc66
            // 
            this.cbxc66.AutoSize = true;
            this.cbxc66.Location = new System.Drawing.Point(6, 42);
            this.cbxc66.Name = "cbxc66";
            this.cbxc66.Size = new System.Drawing.Size(40, 17);
            this.cbxc66.TabIndex = 3;
            this.cbxc66.Text = "24";
            this.cbxc66.UseVisualStyleBackColor = true;
            // 
            // cbxc65
            // 
            this.cbxc65.AutoSize = true;
            this.cbxc65.Location = new System.Drawing.Point(94, 19);
            this.cbxc65.Name = "cbxc65";
            this.cbxc65.Size = new System.Drawing.Size(40, 17);
            this.cbxc65.TabIndex = 2;
            this.cbxc65.Text = "23";
            this.cbxc65.UseVisualStyleBackColor = true;
            // 
            // cbxc64
            // 
            this.cbxc64.AutoSize = true;
            this.cbxc64.Location = new System.Drawing.Point(50, 19);
            this.cbxc64.Name = "cbxc64";
            this.cbxc64.Size = new System.Drawing.Size(40, 17);
            this.cbxc64.TabIndex = 1;
            this.cbxc64.Text = "22";
            this.cbxc64.UseVisualStyleBackColor = true;
            // 
            // cbxc63
            // 
            this.cbxc63.AutoSize = true;
            this.cbxc63.Location = new System.Drawing.Point(6, 19);
            this.cbxc63.Name = "cbxc63";
            this.cbxc63.Size = new System.Drawing.Size(40, 17);
            this.cbxc63.TabIndex = 0;
            this.cbxc63.Text = "21";
            this.cbxc63.UseVisualStyleBackColor = true;
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox10.BackgroundImage")));
            this.pictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox10.Location = new System.Drawing.Point(6, 16);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(100, 81);
            this.pictureBox10.TabIndex = 0;
            this.pictureBox10.TabStop = false;
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.label17);
            this.groupBox17.Controls.Add(this.label18);
            this.groupBox17.Controls.Add(this.groupBox18);
            this.groupBox17.Controls.Add(this.pictureBox9);
            this.groupBox17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox17.Location = new System.Drawing.Point(3, 438);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(404, 107);
            this.groupBox17.TabIndex = 13;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Zapato elegante";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(112, 36);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(78, 13);
            this.label17.TabIndex = 9;
            this.label17.Text = "Color: Negro";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(112, 68);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(79, 13);
            this.label18.TabIndex = 8;
            this.label18.Text = "Precio $ 700";
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.cbxc62);
            this.groupBox18.Controls.Add(this.cbxc61);
            this.groupBox18.Controls.Add(this.cbxc60);
            this.groupBox18.Controls.Add(this.cbxc59);
            this.groupBox18.Controls.Add(this.cbxc58);
            this.groupBox18.Controls.Add(this.cbxc57);
            this.groupBox18.Controls.Add(this.cbxc56);
            this.groupBox18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox18.Location = new System.Drawing.Point(255, 16);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(132, 85);
            this.groupBox18.TabIndex = 7;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Tallas";
            // 
            // cbxc62
            // 
            this.cbxc62.AutoSize = true;
            this.cbxc62.Location = new System.Drawing.Point(6, 65);
            this.cbxc62.Name = "cbxc62";
            this.cbxc62.Size = new System.Drawing.Size(40, 17);
            this.cbxc62.TabIndex = 6;
            this.cbxc62.Text = "27";
            this.cbxc62.UseVisualStyleBackColor = true;
            // 
            // cbxc61
            // 
            this.cbxc61.AutoSize = true;
            this.cbxc61.Location = new System.Drawing.Point(94, 42);
            this.cbxc61.Name = "cbxc61";
            this.cbxc61.Size = new System.Drawing.Size(40, 17);
            this.cbxc61.TabIndex = 5;
            this.cbxc61.Text = "26";
            this.cbxc61.UseVisualStyleBackColor = true;
            // 
            // cbxc60
            // 
            this.cbxc60.AutoSize = true;
            this.cbxc60.Location = new System.Drawing.Point(50, 42);
            this.cbxc60.Name = "cbxc60";
            this.cbxc60.Size = new System.Drawing.Size(40, 17);
            this.cbxc60.TabIndex = 4;
            this.cbxc60.Text = "25";
            this.cbxc60.UseVisualStyleBackColor = true;
            // 
            // cbxc59
            // 
            this.cbxc59.AutoSize = true;
            this.cbxc59.Location = new System.Drawing.Point(6, 42);
            this.cbxc59.Name = "cbxc59";
            this.cbxc59.Size = new System.Drawing.Size(40, 17);
            this.cbxc59.TabIndex = 3;
            this.cbxc59.Text = "24";
            this.cbxc59.UseVisualStyleBackColor = true;
            // 
            // cbxc58
            // 
            this.cbxc58.AutoSize = true;
            this.cbxc58.Location = new System.Drawing.Point(94, 19);
            this.cbxc58.Name = "cbxc58";
            this.cbxc58.Size = new System.Drawing.Size(40, 17);
            this.cbxc58.TabIndex = 2;
            this.cbxc58.Text = "23";
            this.cbxc58.UseVisualStyleBackColor = true;
            // 
            // cbxc57
            // 
            this.cbxc57.AutoSize = true;
            this.cbxc57.Location = new System.Drawing.Point(50, 19);
            this.cbxc57.Name = "cbxc57";
            this.cbxc57.Size = new System.Drawing.Size(40, 17);
            this.cbxc57.TabIndex = 1;
            this.cbxc57.Text = "22";
            this.cbxc57.UseVisualStyleBackColor = true;
            // 
            // cbxc56
            // 
            this.cbxc56.AutoSize = true;
            this.cbxc56.Location = new System.Drawing.Point(6, 19);
            this.cbxc56.Name = "cbxc56";
            this.cbxc56.Size = new System.Drawing.Size(40, 17);
            this.cbxc56.TabIndex = 0;
            this.cbxc56.Text = "21";
            this.cbxc56.UseVisualStyleBackColor = true;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox9.BackgroundImage")));
            this.pictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox9.Location = new System.Drawing.Point(6, 16);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(100, 81);
            this.pictureBox9.TabIndex = 0;
            this.pictureBox9.TabStop = false;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.label15);
            this.groupBox15.Controls.Add(this.label16);
            this.groupBox15.Controls.Add(this.groupBox16);
            this.groupBox15.Controls.Add(this.pictureBox8);
            this.groupBox15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox15.Location = new System.Drawing.Point(413, 325);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(416, 113);
            this.groupBox15.TabIndex = 11;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Zapato con broche";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(112, 36);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(69, 13);
            this.label15.TabIndex = 9;
            this.label15.Text = "Color: Vino";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(112, 68);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(79, 13);
            this.label16.TabIndex = 8;
            this.label16.Text = "Precio $ 900";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.cbxc55);
            this.groupBox16.Controls.Add(this.cbxc54);
            this.groupBox16.Controls.Add(this.cbxc53);
            this.groupBox16.Controls.Add(this.cbxc52);
            this.groupBox16.Controls.Add(this.cbxc51);
            this.groupBox16.Controls.Add(this.cbxc50);
            this.groupBox16.Controls.Add(this.cbxc49);
            this.groupBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox16.Location = new System.Drawing.Point(278, 16);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(132, 85);
            this.groupBox16.TabIndex = 7;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Tallas";
            // 
            // cbxc55
            // 
            this.cbxc55.AutoSize = true;
            this.cbxc55.Location = new System.Drawing.Point(6, 65);
            this.cbxc55.Name = "cbxc55";
            this.cbxc55.Size = new System.Drawing.Size(40, 17);
            this.cbxc55.TabIndex = 6;
            this.cbxc55.Text = "27";
            this.cbxc55.UseVisualStyleBackColor = true;
            // 
            // cbxc54
            // 
            this.cbxc54.AutoSize = true;
            this.cbxc54.Location = new System.Drawing.Point(94, 42);
            this.cbxc54.Name = "cbxc54";
            this.cbxc54.Size = new System.Drawing.Size(40, 17);
            this.cbxc54.TabIndex = 5;
            this.cbxc54.Text = "26";
            this.cbxc54.UseVisualStyleBackColor = true;
            // 
            // cbxc53
            // 
            this.cbxc53.AutoSize = true;
            this.cbxc53.Location = new System.Drawing.Point(50, 42);
            this.cbxc53.Name = "cbxc53";
            this.cbxc53.Size = new System.Drawing.Size(40, 17);
            this.cbxc53.TabIndex = 4;
            this.cbxc53.Text = "25";
            this.cbxc53.UseVisualStyleBackColor = true;
            // 
            // cbxc52
            // 
            this.cbxc52.AutoSize = true;
            this.cbxc52.Location = new System.Drawing.Point(6, 42);
            this.cbxc52.Name = "cbxc52";
            this.cbxc52.Size = new System.Drawing.Size(40, 17);
            this.cbxc52.TabIndex = 3;
            this.cbxc52.Text = "24";
            this.cbxc52.UseVisualStyleBackColor = true;
            // 
            // cbxc51
            // 
            this.cbxc51.AutoSize = true;
            this.cbxc51.Location = new System.Drawing.Point(94, 19);
            this.cbxc51.Name = "cbxc51";
            this.cbxc51.Size = new System.Drawing.Size(40, 17);
            this.cbxc51.TabIndex = 2;
            this.cbxc51.Text = "23";
            this.cbxc51.UseVisualStyleBackColor = true;
            // 
            // cbxc50
            // 
            this.cbxc50.AutoSize = true;
            this.cbxc50.Location = new System.Drawing.Point(50, 19);
            this.cbxc50.Name = "cbxc50";
            this.cbxc50.Size = new System.Drawing.Size(40, 17);
            this.cbxc50.TabIndex = 1;
            this.cbxc50.Text = "22";
            this.cbxc50.UseVisualStyleBackColor = true;
            // 
            // cbxc49
            // 
            this.cbxc49.AutoSize = true;
            this.cbxc49.Location = new System.Drawing.Point(6, 19);
            this.cbxc49.Name = "cbxc49";
            this.cbxc49.Size = new System.Drawing.Size(40, 17);
            this.cbxc49.TabIndex = 0;
            this.cbxc49.Text = "21";
            this.cbxc49.UseVisualStyleBackColor = true;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox8.BackgroundImage")));
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox8.Location = new System.Drawing.Point(6, 16);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(100, 81);
            this.pictureBox8.TabIndex = 0;
            this.pictureBox8.TabStop = false;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label13);
            this.groupBox13.Controls.Add(this.label14);
            this.groupBox13.Controls.Add(this.groupBox14);
            this.groupBox13.Controls.Add(this.pictureBox7);
            this.groupBox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox13.Location = new System.Drawing.Point(3, 325);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(404, 113);
            this.groupBox13.TabIndex = 11;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Botin con elastico";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(112, 36);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(70, 13);
            this.label13.TabIndex = 9;
            this.label13.Text = "Color: Cafe";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(112, 68);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(79, 13);
            this.label14.TabIndex = 8;
            this.label14.Text = "Precio $ 700";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.cbxc70);
            this.groupBox14.Controls.Add(this.cbxc48);
            this.groupBox14.Controls.Add(this.cbxc47);
            this.groupBox14.Controls.Add(this.cbxc46);
            this.groupBox14.Controls.Add(this.cbxc45);
            this.groupBox14.Controls.Add(this.cbxc44);
            this.groupBox14.Controls.Add(this.cbxc43);
            this.groupBox14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox14.Location = new System.Drawing.Point(255, 16);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(132, 85);
            this.groupBox14.TabIndex = 7;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Tallas";
            // 
            // cbxc70
            // 
            this.cbxc70.AutoSize = true;
            this.cbxc70.Location = new System.Drawing.Point(6, 65);
            this.cbxc70.Name = "cbxc70";
            this.cbxc70.Size = new System.Drawing.Size(40, 17);
            this.cbxc70.TabIndex = 6;
            this.cbxc70.Text = "27";
            this.cbxc70.UseVisualStyleBackColor = true;
            // 
            // cbxc48
            // 
            this.cbxc48.AutoSize = true;
            this.cbxc48.Location = new System.Drawing.Point(94, 42);
            this.cbxc48.Name = "cbxc48";
            this.cbxc48.Size = new System.Drawing.Size(40, 17);
            this.cbxc48.TabIndex = 5;
            this.cbxc48.Text = "26";
            this.cbxc48.UseVisualStyleBackColor = true;
            // 
            // cbxc47
            // 
            this.cbxc47.AutoSize = true;
            this.cbxc47.Location = new System.Drawing.Point(50, 42);
            this.cbxc47.Name = "cbxc47";
            this.cbxc47.Size = new System.Drawing.Size(40, 17);
            this.cbxc47.TabIndex = 4;
            this.cbxc47.Text = "25";
            this.cbxc47.UseVisualStyleBackColor = true;
            // 
            // cbxc46
            // 
            this.cbxc46.AutoSize = true;
            this.cbxc46.Location = new System.Drawing.Point(6, 42);
            this.cbxc46.Name = "cbxc46";
            this.cbxc46.Size = new System.Drawing.Size(40, 17);
            this.cbxc46.TabIndex = 3;
            this.cbxc46.Text = "24";
            this.cbxc46.UseVisualStyleBackColor = true;
            // 
            // cbxc45
            // 
            this.cbxc45.AutoSize = true;
            this.cbxc45.Location = new System.Drawing.Point(94, 19);
            this.cbxc45.Name = "cbxc45";
            this.cbxc45.Size = new System.Drawing.Size(40, 17);
            this.cbxc45.TabIndex = 2;
            this.cbxc45.Text = "23";
            this.cbxc45.UseVisualStyleBackColor = true;
            // 
            // cbxc44
            // 
            this.cbxc44.AutoSize = true;
            this.cbxc44.Location = new System.Drawing.Point(50, 19);
            this.cbxc44.Name = "cbxc44";
            this.cbxc44.Size = new System.Drawing.Size(40, 17);
            this.cbxc44.TabIndex = 1;
            this.cbxc44.Text = "22";
            this.cbxc44.UseVisualStyleBackColor = true;
            // 
            // cbxc43
            // 
            this.cbxc43.AutoSize = true;
            this.cbxc43.Location = new System.Drawing.Point(6, 19);
            this.cbxc43.Name = "cbxc43";
            this.cbxc43.Size = new System.Drawing.Size(40, 17);
            this.cbxc43.TabIndex = 0;
            this.cbxc43.Text = "21";
            this.cbxc43.UseVisualStyleBackColor = true;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox7.BackgroundImage")));
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox7.Location = new System.Drawing.Point(6, 16);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(100, 81);
            this.pictureBox7.TabIndex = 0;
            this.pictureBox7.TabStop = false;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label11);
            this.groupBox11.Controls.Add(this.label12);
            this.groupBox11.Controls.Add(this.groupBox12);
            this.groupBox11.Controls.Add(this.pictureBox6);
            this.groupBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox11.Location = new System.Drawing.Point(413, 218);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(416, 107);
            this.groupBox11.TabIndex = 10;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Bota c/ cordones";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(112, 36);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(78, 13);
            this.label11.TabIndex = 9;
            this.label11.Text = "Color: Negro";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(112, 68);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(79, 13);
            this.label12.TabIndex = 8;
            this.label12.Text = "Precio $ 680";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.cbxc42);
            this.groupBox12.Controls.Add(this.cbxc41);
            this.groupBox12.Controls.Add(this.cbxc40);
            this.groupBox12.Controls.Add(this.cbxc39);
            this.groupBox12.Controls.Add(this.cbxc38);
            this.groupBox12.Controls.Add(this.cbxc37);
            this.groupBox12.Controls.Add(this.cbxc36);
            this.groupBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox12.Location = new System.Drawing.Point(278, 16);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(132, 85);
            this.groupBox12.TabIndex = 7;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Tallas";
            // 
            // cbxc42
            // 
            this.cbxc42.AutoSize = true;
            this.cbxc42.Location = new System.Drawing.Point(6, 65);
            this.cbxc42.Name = "cbxc42";
            this.cbxc42.Size = new System.Drawing.Size(40, 17);
            this.cbxc42.TabIndex = 6;
            this.cbxc42.Text = "27";
            this.cbxc42.UseVisualStyleBackColor = true;
            // 
            // cbxc41
            // 
            this.cbxc41.AutoSize = true;
            this.cbxc41.Location = new System.Drawing.Point(94, 42);
            this.cbxc41.Name = "cbxc41";
            this.cbxc41.Size = new System.Drawing.Size(40, 17);
            this.cbxc41.TabIndex = 5;
            this.cbxc41.Text = "26";
            this.cbxc41.UseVisualStyleBackColor = true;
            // 
            // cbxc40
            // 
            this.cbxc40.AutoSize = true;
            this.cbxc40.Location = new System.Drawing.Point(50, 42);
            this.cbxc40.Name = "cbxc40";
            this.cbxc40.Size = new System.Drawing.Size(40, 17);
            this.cbxc40.TabIndex = 4;
            this.cbxc40.Text = "25";
            this.cbxc40.UseVisualStyleBackColor = true;
            // 
            // cbxc39
            // 
            this.cbxc39.AutoSize = true;
            this.cbxc39.Location = new System.Drawing.Point(6, 42);
            this.cbxc39.Name = "cbxc39";
            this.cbxc39.Size = new System.Drawing.Size(40, 17);
            this.cbxc39.TabIndex = 3;
            this.cbxc39.Text = "24";
            this.cbxc39.UseVisualStyleBackColor = true;
            // 
            // cbxc38
            // 
            this.cbxc38.AutoSize = true;
            this.cbxc38.Location = new System.Drawing.Point(94, 19);
            this.cbxc38.Name = "cbxc38";
            this.cbxc38.Size = new System.Drawing.Size(40, 17);
            this.cbxc38.TabIndex = 2;
            this.cbxc38.Text = "23";
            this.cbxc38.UseVisualStyleBackColor = true;
            // 
            // cbxc37
            // 
            this.cbxc37.AutoSize = true;
            this.cbxc37.Location = new System.Drawing.Point(50, 19);
            this.cbxc37.Name = "cbxc37";
            this.cbxc37.Size = new System.Drawing.Size(40, 17);
            this.cbxc37.TabIndex = 1;
            this.cbxc37.Text = "22";
            this.cbxc37.UseVisualStyleBackColor = true;
            // 
            // cbxc36
            // 
            this.cbxc36.AutoSize = true;
            this.cbxc36.Location = new System.Drawing.Point(6, 19);
            this.cbxc36.Name = "cbxc36";
            this.cbxc36.Size = new System.Drawing.Size(40, 17);
            this.cbxc36.TabIndex = 0;
            this.cbxc36.Text = "21";
            this.cbxc36.UseVisualStyleBackColor = true;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.BackgroundImage")));
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox6.Location = new System.Drawing.Point(6, 16);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(100, 81);
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label9);
            this.groupBox9.Controls.Add(this.label10);
            this.groupBox9.Controls.Add(this.groupBox10);
            this.groupBox9.Controls.Add(this.pictureBox5);
            this.groupBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.Location = new System.Drawing.Point(3, 218);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(404, 107);
            this.groupBox9.TabIndex = 10;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Mocasin";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(112, 36);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 13);
            this.label9.TabIndex = 9;
            this.label9.Text = "Color: Negro";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(112, 68);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(79, 13);
            this.label10.TabIndex = 8;
            this.label10.Text = "Precio $ 400";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.cbxc35);
            this.groupBox10.Controls.Add(this.cbxc34);
            this.groupBox10.Controls.Add(this.cbxc33);
            this.groupBox10.Controls.Add(this.cbxc32);
            this.groupBox10.Controls.Add(this.cbxc31);
            this.groupBox10.Controls.Add(this.cbxc30);
            this.groupBox10.Controls.Add(this.cbxc29);
            this.groupBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.Location = new System.Drawing.Point(255, 16);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(132, 85);
            this.groupBox10.TabIndex = 7;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Tallas";
            // 
            // cbxc35
            // 
            this.cbxc35.AutoSize = true;
            this.cbxc35.Location = new System.Drawing.Point(6, 65);
            this.cbxc35.Name = "cbxc35";
            this.cbxc35.Size = new System.Drawing.Size(40, 17);
            this.cbxc35.TabIndex = 6;
            this.cbxc35.Text = "27";
            this.cbxc35.UseVisualStyleBackColor = true;
            // 
            // cbxc34
            // 
            this.cbxc34.AutoSize = true;
            this.cbxc34.Location = new System.Drawing.Point(94, 42);
            this.cbxc34.Name = "cbxc34";
            this.cbxc34.Size = new System.Drawing.Size(40, 17);
            this.cbxc34.TabIndex = 5;
            this.cbxc34.Text = "26";
            this.cbxc34.UseVisualStyleBackColor = true;
            // 
            // cbxc33
            // 
            this.cbxc33.AutoSize = true;
            this.cbxc33.Location = new System.Drawing.Point(50, 42);
            this.cbxc33.Name = "cbxc33";
            this.cbxc33.Size = new System.Drawing.Size(40, 17);
            this.cbxc33.TabIndex = 4;
            this.cbxc33.Text = "25";
            this.cbxc33.UseVisualStyleBackColor = true;
            // 
            // cbxc32
            // 
            this.cbxc32.AutoSize = true;
            this.cbxc32.Location = new System.Drawing.Point(6, 42);
            this.cbxc32.Name = "cbxc32";
            this.cbxc32.Size = new System.Drawing.Size(40, 17);
            this.cbxc32.TabIndex = 3;
            this.cbxc32.Text = "24";
            this.cbxc32.UseVisualStyleBackColor = true;
            // 
            // cbxc31
            // 
            this.cbxc31.AutoSize = true;
            this.cbxc31.Location = new System.Drawing.Point(94, 19);
            this.cbxc31.Name = "cbxc31";
            this.cbxc31.Size = new System.Drawing.Size(40, 17);
            this.cbxc31.TabIndex = 2;
            this.cbxc31.Text = "23";
            this.cbxc31.UseVisualStyleBackColor = true;
            // 
            // cbxc30
            // 
            this.cbxc30.AutoSize = true;
            this.cbxc30.Location = new System.Drawing.Point(50, 19);
            this.cbxc30.Name = "cbxc30";
            this.cbxc30.Size = new System.Drawing.Size(40, 17);
            this.cbxc30.TabIndex = 1;
            this.cbxc30.Text = "22";
            this.cbxc30.UseVisualStyleBackColor = true;
            // 
            // cbxc29
            // 
            this.cbxc29.AutoSize = true;
            this.cbxc29.Location = new System.Drawing.Point(6, 19);
            this.cbxc29.Name = "cbxc29";
            this.cbxc29.Size = new System.Drawing.Size(40, 17);
            this.cbxc29.TabIndex = 0;
            this.cbxc29.Text = "21";
            this.cbxc29.UseVisualStyleBackColor = true;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.BackgroundImage")));
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox5.Location = new System.Drawing.Point(6, 16);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(100, 81);
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label7);
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Controls.Add(this.groupBox8);
            this.groupBox6.Controls.Add(this.pictureBox4);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(413, 111);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(416, 107);
            this.groupBox6.TabIndex = 12;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Sandalia ajustable";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(112, 36);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(78, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Color: Negro";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(112, 68);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "Precio $ 200";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.cbxc28);
            this.groupBox8.Controls.Add(this.cbxc27);
            this.groupBox8.Controls.Add(this.cbxc26);
            this.groupBox8.Controls.Add(this.cbxc25);
            this.groupBox8.Controls.Add(this.cbxc24);
            this.groupBox8.Controls.Add(this.cbxc23);
            this.groupBox8.Controls.Add(this.cbxc22);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(278, 19);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(132, 85);
            this.groupBox8.TabIndex = 7;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Tallas";
            // 
            // cbxc28
            // 
            this.cbxc28.AutoSize = true;
            this.cbxc28.Location = new System.Drawing.Point(6, 65);
            this.cbxc28.Name = "cbxc28";
            this.cbxc28.Size = new System.Drawing.Size(40, 17);
            this.cbxc28.TabIndex = 6;
            this.cbxc28.Text = "27";
            this.cbxc28.UseVisualStyleBackColor = true;
            // 
            // cbxc27
            // 
            this.cbxc27.AutoSize = true;
            this.cbxc27.Location = new System.Drawing.Point(94, 42);
            this.cbxc27.Name = "cbxc27";
            this.cbxc27.Size = new System.Drawing.Size(40, 17);
            this.cbxc27.TabIndex = 5;
            this.cbxc27.Text = "26";
            this.cbxc27.UseVisualStyleBackColor = true;
            // 
            // cbxc26
            // 
            this.cbxc26.AutoSize = true;
            this.cbxc26.Location = new System.Drawing.Point(50, 42);
            this.cbxc26.Name = "cbxc26";
            this.cbxc26.Size = new System.Drawing.Size(40, 17);
            this.cbxc26.TabIndex = 4;
            this.cbxc26.Text = "25";
            this.cbxc26.UseVisualStyleBackColor = true;
            // 
            // cbxc25
            // 
            this.cbxc25.AutoSize = true;
            this.cbxc25.Location = new System.Drawing.Point(6, 42);
            this.cbxc25.Name = "cbxc25";
            this.cbxc25.Size = new System.Drawing.Size(40, 17);
            this.cbxc25.TabIndex = 3;
            this.cbxc25.Text = "24";
            this.cbxc25.UseVisualStyleBackColor = true;
            // 
            // cbxc24
            // 
            this.cbxc24.AutoSize = true;
            this.cbxc24.Location = new System.Drawing.Point(94, 19);
            this.cbxc24.Name = "cbxc24";
            this.cbxc24.Size = new System.Drawing.Size(40, 17);
            this.cbxc24.TabIndex = 2;
            this.cbxc24.Text = "23";
            this.cbxc24.UseVisualStyleBackColor = true;
            // 
            // cbxc23
            // 
            this.cbxc23.AutoSize = true;
            this.cbxc23.Location = new System.Drawing.Point(50, 19);
            this.cbxc23.Name = "cbxc23";
            this.cbxc23.Size = new System.Drawing.Size(40, 17);
            this.cbxc23.TabIndex = 1;
            this.cbxc23.Text = "22";
            this.cbxc23.UseVisualStyleBackColor = true;
            // 
            // cbxc22
            // 
            this.cbxc22.AutoSize = true;
            this.cbxc22.Location = new System.Drawing.Point(6, 19);
            this.cbxc22.Name = "cbxc22";
            this.cbxc22.Size = new System.Drawing.Size(40, 17);
            this.cbxc22.TabIndex = 0;
            this.cbxc22.Text = "21";
            this.cbxc22.UseVisualStyleBackColor = true;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox4.Location = new System.Drawing.Point(6, 16);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(100, 81);
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.groupBox5);
            this.groupBox4.Controls.Add(this.pictureBox3);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(3, 111);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(404, 107);
            this.groupBox4.TabIndex = 11;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Zapato ejecutivo";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(112, 36);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Color: Negro";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(112, 68);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Precio $ 800";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.cbxc21);
            this.groupBox5.Controls.Add(this.cbxc20);
            this.groupBox5.Controls.Add(this.cbxc19);
            this.groupBox5.Controls.Add(this.cbxc18);
            this.groupBox5.Controls.Add(this.cbxc17);
            this.groupBox5.Controls.Add(this.cbxc16);
            this.groupBox5.Controls.Add(this.cbxc15);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(255, 13);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(132, 85);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Tallas";
            // 
            // cbxc21
            // 
            this.cbxc21.AutoSize = true;
            this.cbxc21.Location = new System.Drawing.Point(6, 65);
            this.cbxc21.Name = "cbxc21";
            this.cbxc21.Size = new System.Drawing.Size(40, 17);
            this.cbxc21.TabIndex = 6;
            this.cbxc21.Text = "27";
            this.cbxc21.UseVisualStyleBackColor = true;
            // 
            // cbxc20
            // 
            this.cbxc20.AutoSize = true;
            this.cbxc20.Location = new System.Drawing.Point(94, 42);
            this.cbxc20.Name = "cbxc20";
            this.cbxc20.Size = new System.Drawing.Size(40, 17);
            this.cbxc20.TabIndex = 5;
            this.cbxc20.Text = "26";
            this.cbxc20.UseVisualStyleBackColor = true;
            // 
            // cbxc19
            // 
            this.cbxc19.AutoSize = true;
            this.cbxc19.Location = new System.Drawing.Point(50, 42);
            this.cbxc19.Name = "cbxc19";
            this.cbxc19.Size = new System.Drawing.Size(40, 17);
            this.cbxc19.TabIndex = 4;
            this.cbxc19.Text = "25";
            this.cbxc19.UseVisualStyleBackColor = true;
            // 
            // cbxc18
            // 
            this.cbxc18.AutoSize = true;
            this.cbxc18.Location = new System.Drawing.Point(6, 42);
            this.cbxc18.Name = "cbxc18";
            this.cbxc18.Size = new System.Drawing.Size(40, 17);
            this.cbxc18.TabIndex = 3;
            this.cbxc18.Text = "24";
            this.cbxc18.UseVisualStyleBackColor = true;
            // 
            // cbxc17
            // 
            this.cbxc17.AutoSize = true;
            this.cbxc17.Location = new System.Drawing.Point(94, 19);
            this.cbxc17.Name = "cbxc17";
            this.cbxc17.Size = new System.Drawing.Size(40, 17);
            this.cbxc17.TabIndex = 2;
            this.cbxc17.Text = "23";
            this.cbxc17.UseVisualStyleBackColor = true;
            // 
            // cbxc16
            // 
            this.cbxc16.AutoSize = true;
            this.cbxc16.Location = new System.Drawing.Point(50, 19);
            this.cbxc16.Name = "cbxc16";
            this.cbxc16.Size = new System.Drawing.Size(40, 17);
            this.cbxc16.TabIndex = 1;
            this.cbxc16.Text = "22";
            this.cbxc16.UseVisualStyleBackColor = true;
            // 
            // cbxc15
            // 
            this.cbxc15.AutoSize = true;
            this.cbxc15.Location = new System.Drawing.Point(6, 19);
            this.cbxc15.Name = "cbxc15";
            this.cbxc15.Size = new System.Drawing.Size(40, 17);
            this.cbxc15.TabIndex = 0;
            this.cbxc15.Text = "21";
            this.cbxc15.UseVisualStyleBackColor = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox3.Location = new System.Drawing.Point(6, 16);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 81);
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(413, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(416, 107);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Botin c/ cordones";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(112, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Color: Cafe oscuro";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(112, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Precio $ 500";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbxc14);
            this.groupBox3.Controls.Add(this.cbxc13);
            this.groupBox3.Controls.Add(this.cbxc12);
            this.groupBox3.Controls.Add(this.cbxc11);
            this.groupBox3.Controls.Add(this.cbxc10);
            this.groupBox3.Controls.Add(this.cbxc9);
            this.groupBox3.Controls.Add(this.cbxc8);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(278, 16);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(132, 85);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Tallas";
            // 
            // cbxc14
            // 
            this.cbxc14.AutoSize = true;
            this.cbxc14.Location = new System.Drawing.Point(6, 65);
            this.cbxc14.Name = "cbxc14";
            this.cbxc14.Size = new System.Drawing.Size(40, 17);
            this.cbxc14.TabIndex = 6;
            this.cbxc14.Text = "27";
            this.cbxc14.UseVisualStyleBackColor = true;
            // 
            // cbxc13
            // 
            this.cbxc13.AutoSize = true;
            this.cbxc13.Location = new System.Drawing.Point(94, 42);
            this.cbxc13.Name = "cbxc13";
            this.cbxc13.Size = new System.Drawing.Size(40, 17);
            this.cbxc13.TabIndex = 5;
            this.cbxc13.Text = "26";
            this.cbxc13.UseVisualStyleBackColor = true;
            // 
            // cbxc12
            // 
            this.cbxc12.AutoSize = true;
            this.cbxc12.Location = new System.Drawing.Point(50, 42);
            this.cbxc12.Name = "cbxc12";
            this.cbxc12.Size = new System.Drawing.Size(40, 17);
            this.cbxc12.TabIndex = 4;
            this.cbxc12.Text = "25";
            this.cbxc12.UseVisualStyleBackColor = true;
            // 
            // cbxc11
            // 
            this.cbxc11.AutoSize = true;
            this.cbxc11.Location = new System.Drawing.Point(6, 42);
            this.cbxc11.Name = "cbxc11";
            this.cbxc11.Size = new System.Drawing.Size(40, 17);
            this.cbxc11.TabIndex = 3;
            this.cbxc11.Text = "24";
            this.cbxc11.UseVisualStyleBackColor = true;
            // 
            // cbxc10
            // 
            this.cbxc10.AutoSize = true;
            this.cbxc10.Location = new System.Drawing.Point(94, 19);
            this.cbxc10.Name = "cbxc10";
            this.cbxc10.Size = new System.Drawing.Size(40, 17);
            this.cbxc10.TabIndex = 2;
            this.cbxc10.Text = "23";
            this.cbxc10.UseVisualStyleBackColor = true;
            // 
            // cbxc9
            // 
            this.cbxc9.AutoSize = true;
            this.cbxc9.Location = new System.Drawing.Point(50, 19);
            this.cbxc9.Name = "cbxc9";
            this.cbxc9.Size = new System.Drawing.Size(40, 17);
            this.cbxc9.TabIndex = 1;
            this.cbxc9.Text = "22";
            this.cbxc9.UseVisualStyleBackColor = true;
            // 
            // cbxc8
            // 
            this.cbxc8.AutoSize = true;
            this.cbxc8.Location = new System.Drawing.Point(6, 19);
            this.cbxc8.Name = "cbxc8";
            this.cbxc8.Size = new System.Drawing.Size(40, 17);
            this.cbxc8.TabIndex = 0;
            this.cbxc8.Text = "21";
            this.cbxc8.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Location = new System.Drawing.Point(6, 16);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 81);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // btnregresar
            // 
            this.btnregresar.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnregresar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnregresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnregresar.Location = new System.Drawing.Point(573, 390);
            this.btnregresar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnregresar.Name = "btnregresar";
            this.btnregresar.Size = new System.Drawing.Size(145, 36);
            this.btnregresar.TabIndex = 7;
            this.btnregresar.Text = "Regresar";
            this.btnregresar.UseVisualStyleBackColor = false;
            this.btnregresar.Click += new System.EventHandler(this.btnregresar_Click);
            // 
            // frmProdcaballeros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(864, 465);
            this.Controls.Add(this.btnregresar);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnagregar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmProdcaballeros";
            this.Text = "Productos Caballeros";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.CheckBox cbxc7;
        private System.Windows.Forms.CheckBox cbxc6;
        private System.Windows.Forms.CheckBox cbxc5;
        private System.Windows.Forms.CheckBox cbxc4;
        private System.Windows.Forms.CheckBox cbxc3;
        private System.Windows.Forms.CheckBox cbxc2;
        private System.Windows.Forms.CheckBox cbxc1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnagregar;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox cbxc14;
        private System.Windows.Forms.CheckBox cbxc13;
        private System.Windows.Forms.CheckBox cbxc12;
        private System.Windows.Forms.CheckBox cbxc11;
        private System.Windows.Forms.CheckBox cbxc10;
        private System.Windows.Forms.CheckBox cbxc9;
        private System.Windows.Forms.CheckBox cbxc8;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.CheckBox cbxc69;
        private System.Windows.Forms.CheckBox cbxc68;
        private System.Windows.Forms.CheckBox cbxc67;
        private System.Windows.Forms.CheckBox cbxc66;
        private System.Windows.Forms.CheckBox cbxc65;
        private System.Windows.Forms.CheckBox cbxc64;
        private System.Windows.Forms.CheckBox cbxc63;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.CheckBox cbxc62;
        private System.Windows.Forms.CheckBox cbxc61;
        private System.Windows.Forms.CheckBox cbxc60;
        private System.Windows.Forms.CheckBox cbxc59;
        private System.Windows.Forms.CheckBox cbxc58;
        private System.Windows.Forms.CheckBox cbxc57;
        private System.Windows.Forms.CheckBox cbxc56;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.CheckBox cbxc55;
        private System.Windows.Forms.CheckBox cbxc54;
        private System.Windows.Forms.CheckBox cbxc53;
        private System.Windows.Forms.CheckBox cbxc52;
        private System.Windows.Forms.CheckBox cbxc51;
        private System.Windows.Forms.CheckBox cbxc50;
        private System.Windows.Forms.CheckBox cbxc49;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.CheckBox cbxc70;
        private System.Windows.Forms.CheckBox cbxc48;
        private System.Windows.Forms.CheckBox cbxc47;
        private System.Windows.Forms.CheckBox cbxc46;
        private System.Windows.Forms.CheckBox cbxc45;
        private System.Windows.Forms.CheckBox cbxc44;
        private System.Windows.Forms.CheckBox cbxc43;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.CheckBox cbxc42;
        private System.Windows.Forms.CheckBox cbxc41;
        private System.Windows.Forms.CheckBox cbxc40;
        private System.Windows.Forms.CheckBox cbxc39;
        private System.Windows.Forms.CheckBox cbxc38;
        private System.Windows.Forms.CheckBox cbxc37;
        private System.Windows.Forms.CheckBox cbxc36;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.CheckBox cbxc35;
        private System.Windows.Forms.CheckBox cbxc34;
        private System.Windows.Forms.CheckBox cbxc33;
        private System.Windows.Forms.CheckBox cbxc32;
        private System.Windows.Forms.CheckBox cbxc31;
        private System.Windows.Forms.CheckBox cbxc30;
        private System.Windows.Forms.CheckBox cbxc29;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.CheckBox cbxc28;
        private System.Windows.Forms.CheckBox cbxc27;
        private System.Windows.Forms.CheckBox cbxc26;
        private System.Windows.Forms.CheckBox cbxc25;
        private System.Windows.Forms.CheckBox cbxc24;
        private System.Windows.Forms.CheckBox cbxc23;
        private System.Windows.Forms.CheckBox cbxc22;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.CheckBox cbxc21;
        private System.Windows.Forms.CheckBox cbxc20;
        private System.Windows.Forms.CheckBox cbxc19;
        private System.Windows.Forms.CheckBox cbxc18;
        private System.Windows.Forms.CheckBox cbxc17;
        private System.Windows.Forms.CheckBox cbxc16;
        private System.Windows.Forms.CheckBox cbxc15;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btnregresar;
    }
}