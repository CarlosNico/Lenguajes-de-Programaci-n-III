﻿namespace CRUD.Formularios
{
    partial class frmCompras
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCompras));
            this.dgvcompras = new System.Windows.Forms.DataGridView();
            this.btnmostrar = new System.Windows.Forms.Button();
            this.btnregresar = new System.Windows.Forms.Button();
            this.btncompra = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtcliente = new System.Windows.Forms.TextBox();
            this.txtproducto = new System.Windows.Forms.TextBox();
            this.btncomprascliente = new System.Windows.Forms.Button();
            this.btncomprasyear = new System.Windows.Forms.Button();
            this.txtano = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btncomprasproducto = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvcompras)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvcompras
            // 
            this.dgvcompras.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvcompras.Location = new System.Drawing.Point(30, 138);
            this.dgvcompras.Name = "dgvcompras";
            this.dgvcompras.Size = new System.Drawing.Size(726, 274);
            this.dgvcompras.TabIndex = 0;
            // 
            // btnmostrar
            // 
            this.btnmostrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnmostrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmostrar.Location = new System.Drawing.Point(434, 79);
            this.btnmostrar.Name = "btnmostrar";
            this.btnmostrar.Size = new System.Drawing.Size(106, 34);
            this.btnmostrar.TabIndex = 1;
            this.btnmostrar.Text = "Mostrar";
            this.btnmostrar.UseVisualStyleBackColor = true;
            this.btnmostrar.Click += new System.EventHandler(this.btnmostrar_Click);
            // 
            // btnregresar
            // 
            this.btnregresar.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnregresar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnregresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnregresar.Location = new System.Drawing.Point(712, 418);
            this.btnregresar.Name = "btnregresar";
            this.btnregresar.Size = new System.Drawing.Size(85, 27);
            this.btnregresar.TabIndex = 2;
            this.btnregresar.Text = "Regresar";
            this.btnregresar.UseVisualStyleBackColor = false;
            this.btnregresar.Click += new System.EventHandler(this.btnregresar_Click);
            // 
            // btncompra
            // 
            this.btncompra.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btncompra.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncompra.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncompra.Location = new System.Drawing.Point(578, 79);
            this.btncompra.Name = "btncompra";
            this.btncompra.Size = new System.Drawing.Size(106, 34);
            this.btncompra.TabIndex = 3;
            this.btncompra.Text = "Registrar Compra";
            this.btncompra.UseVisualStyleBackColor = false;
            this.btncompra.Click += new System.EventHandler(this.btncompra_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(30, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "ID Cliente";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(30, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "ID Producto";
            // 
            // txtcliente
            // 
            this.txtcliente.Location = new System.Drawing.Point(152, 13);
            this.txtcliente.Name = "txtcliente";
            this.txtcliente.Size = new System.Drawing.Size(100, 20);
            this.txtcliente.TabIndex = 6;
            // 
            // txtproducto
            // 
            this.txtproducto.Location = new System.Drawing.Point(152, 43);
            this.txtproducto.Name = "txtproducto";
            this.txtproducto.Size = new System.Drawing.Size(100, 20);
            this.txtproducto.TabIndex = 7;
            // 
            // btncomprascliente
            // 
            this.btncomprascliente.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btncomprascliente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncomprascliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncomprascliente.Location = new System.Drawing.Point(375, 23);
            this.btncomprascliente.Name = "btncomprascliente";
            this.btncomprascliente.Size = new System.Drawing.Size(106, 36);
            this.btncomprascliente.TabIndex = 8;
            this.btncomprascliente.Text = "Compras por cliente";
            this.btncomprascliente.UseVisualStyleBackColor = false;
            this.btncomprascliente.Click += new System.EventHandler(this.btncomprascliente_Click);
            // 
            // btncomprasyear
            // 
            this.btncomprasyear.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btncomprasyear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncomprasyear.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncomprasyear.Location = new System.Drawing.Point(626, 23);
            this.btncomprasyear.Name = "btncomprasyear";
            this.btncomprasyear.Size = new System.Drawing.Size(106, 36);
            this.btncomprasyear.TabIndex = 9;
            this.btncomprasyear.Text = "Compras por año";
            this.btncomprasyear.UseVisualStyleBackColor = false;
            this.btncomprasyear.Click += new System.EventHandler(this.btncomprasyear_Click);
            // 
            // txtano
            // 
            this.txtano.Location = new System.Drawing.Point(152, 76);
            this.txtano.Name = "txtano";
            this.txtano.Size = new System.Drawing.Size(100, 20);
            this.txtano.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(30, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 16);
            this.label3.TabIndex = 11;
            this.label3.Text = "Año";
            // 
            // btncomprasproducto
            // 
            this.btncomprasproducto.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btncomprasproducto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncomprasproducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncomprasproducto.Location = new System.Drawing.Point(502, 23);
            this.btncomprasproducto.Name = "btncomprasproducto";
            this.btncomprasproducto.Size = new System.Drawing.Size(106, 36);
            this.btncomprasproducto.TabIndex = 12;
            this.btncomprasproducto.Text = "Compras por producto";
            this.btncomprasproducto.UseVisualStyleBackColor = false;
            this.btncomprasproducto.Click += new System.EventHandler(this.btncomprasproducto_Click);
            // 
            // frmCompras
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btncomprasproducto);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtano);
            this.Controls.Add(this.btncomprasyear);
            this.Controls.Add(this.btncomprascliente);
            this.Controls.Add(this.txtproducto);
            this.Controls.Add(this.txtcliente);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btncompra);
            this.Controls.Add(this.btnregresar);
            this.Controls.Add(this.btnmostrar);
            this.Controls.Add(this.dgvcompras);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmCompras";
            this.Text = "Compras";
            ((System.ComponentModel.ISupportInitialize)(this.dgvcompras)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvcompras;
        private System.Windows.Forms.Button btnmostrar;
        private System.Windows.Forms.Button btnregresar;
        private System.Windows.Forms.Button btncompra;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtcliente;
        private System.Windows.Forms.TextBox txtproducto;
        private System.Windows.Forms.Button btncomprascliente;
        private System.Windows.Forms.Button btncomprasyear;
        private System.Windows.Forms.TextBox txtano;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btncomprasproducto;
    }
}