﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUD.Formularios
{
    public partial class frmProdcaballeros : Form
    {
        public frmProdcaballeros()
        {
            InitializeComponent();
        }
    private void LimpiarCTrs(object sender, EventArgs e)
        {
            foreach (Control ctr in this.Controls)
            {
                if (ctr is TextBox)
                    ctr.Text = string.Empty;

                else if (ctr is ComboBox)
                   ((ComboBox) ctr).SelectedIndex = -1;

                else if(ctr is CheckBox)
                {
                    if (((CheckBox)ctr).Checked)
                        ((CheckBox)ctr).Checked = false;                    
                }
            }
        }

        private void btnagregar_Click(object sender, EventArgs e)
        {
            
            MessageBox.Show("Productos agregados al carrito");
            cbxc1.Checked = false;
            cbxc2.Checked = false;
            cbxc3.Checked = false;
            cbxc4.Checked = false;
            cbxc5.Checked = false;
            cbxc6.Checked = false;
            cbxc7.Checked = false;
            cbxc8.Checked = false;
            cbxc9.Checked = false;
            cbxc10.Checked = false;
            cbxc11.Checked = false;
            cbxc12.Checked = false;
            cbxc13.Checked = false;
            cbxc14.Checked = false;
            cbxc15.Checked = false;
            cbxc16.Checked = false;
            cbxc17.Checked = false;
            cbxc18.Checked = false;
            cbxc19.Checked = false;
            cbxc20.Checked = false;
            cbxc21.Checked = false;
            cbxc22.Checked = false;
            cbxc23.Checked = false;
            cbxc24.Checked = false;
            cbxc25.Checked = false;
            cbxc26.Checked = false;
            cbxc27.Checked = false;
            cbxc28.Checked = false;
            cbxc29.Checked = false;
            cbxc30.Checked = false;
            cbxc31.Checked = false;
            cbxc32.Checked = false;
            cbxc33.Checked = false;
            cbxc34.Checked = false;
            cbxc35.Checked = false;
            cbxc36.Checked = false;
            cbxc37.Checked = false;
            cbxc38.Checked = false;
            cbxc39.Checked = false;
            cbxc40.Checked = false;
            cbxc41.Checked = false;
            cbxc42.Checked = false;
            cbxc43.Checked = false;
            cbxc44.Checked = false;
            cbxc45.Checked = false;
            cbxc46.Checked = false;
            cbxc47.Checked = false;
            cbxc48.Checked = false;
            cbxc49.Checked = false;
            cbxc50.Checked = false;
            cbxc51.Checked = false;
            cbxc52.Checked = false;
            cbxc53.Checked = false;
            cbxc54.Checked = false;
            cbxc55.Checked = false;
            cbxc56.Checked = false;
            cbxc57.Checked = false;
            cbxc58.Checked = false;
            cbxc59.Checked = false;
            cbxc60.Checked = false;
            cbxc61.Checked = false;
            cbxc62.Checked = false;
            cbxc63.Checked = false;
            cbxc64.Checked = false;
            cbxc65.Checked = false;
            cbxc66.Checked = false;
            cbxc67.Checked = false;
            cbxc68.Checked = false;
            cbxc69.Checked = false;
            cbxc70.Checked = false;
        }

        private void btnregresar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}

