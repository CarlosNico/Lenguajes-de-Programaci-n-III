﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CRUD.Formularios
{
    public partial class frmRegcliente : Form
    {
        public frmRegcliente()
        {
            InitializeComponent();
        }

        private void btnagregar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=DESKTOP-5AVHSPI\\SQLEXPRESS;Initial Catalog=ZapateriaUmi;Integrated Security=True;Encrypt=False"))
            {
                if (txtdni.Text == "" | txtnombre.Text == "" | txtapellido.Text == "" | txtfechanac.Text == "" | txttelefono.Text == "" | txtemail.Text == "")
                {
                    MessageBox.Show("Por favor llenar todos los campos de campos");
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("INSERT into CLIENTE (dni, nombre, apellidos, fechaNac, tfno, email) values ('" + txtdni.Text + "','" + txtnombre.Text + "', '" + txtapellido.Text + "', '" + txtfechanac.Text + "', '" + txttelefono.Text + "', '" + txtemail.Text + "')", cn);
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Se agrego exitosamente a " + txtnombre.Text + ".");
                    txtnombre.Clear();
                    txtapellido.Clear();
                    txtfechanac.Clear();
                    txttelefono.Clear();
                    txtemail.Clear();
                    txtdni.Clear();
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=DESKTOP-5AVHSPI\\SQLEXPRESS;Initial Catalog=ZapateriaUmi;Integrated Security=True;Encrypt=False"))
            {
                if (txtnombre.Text == "" | txtapellido.Text == "" | txtfechanac.Text == "" | txttelefono.Text == "" | txtemail.Text == "")
                {
                    MessageBox.Show("Por favor llenar todos los campos de campos");
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("UPDATE CLIENTE set nombre = '" + txtnombre.Text + "', apellidos = '" + txtapellido.Text + "', fechaNac = '" + txtfechanac.Text + "', tfno = '" + txttelefono.Text + "', email = '" + txtemail.Text + "' where dni = '" + txtdni.Text + "'", cn);
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Se modifico exitosamente a " + txtnombre.Text + ".");
                    txtnombre.Clear();
                    txtapellido.Clear();
                    txtfechanac.Clear();
                    txttelefono.Clear();
                    txtemail.Clear();
                    txtdni.Clear();
                }
            }
        }

        private void btneliminar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=DESKTOP-5AVHSPI\\SQLEXPRESS;Initial Catalog=ZapateriaUmi;Integrated Security=True;Encrypt=False"))
            {
                if (txtdni.Text == "")
                {
                    MessageBox.Show("Por favor llenar el campo DNI");
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("DELETE from CLIENTE where dni = '" + txtdni.Text + "'", cn);
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Se elimino exitosamente el cliente");
                    txtdni.Clear();
                }
            }
        }

        private void btnmostrar_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlConnection cn = new SqlConnection("Data Source=DESKTOP-5AVHSPI\\SQLEXPRESS;Initial Catalog=ZapateriaUmi;Integrated Security=True;Encrypt=False"))
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * from CLIENTE", cn);
                da.SelectCommand.CommandType = CommandType.Text;
                cn.Open();
                da.Fill(dt);
                dgvcliente.DataSource = dt;
            }
        }

        private void btnregresar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}

