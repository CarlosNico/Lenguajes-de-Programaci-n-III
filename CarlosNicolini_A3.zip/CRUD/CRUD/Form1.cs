﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUD
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void mensajeDeBienvenidaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bienvenido a la tienda en linea Zapateria UMI, donde podrá encontrar todo lo que usted necesita y si no lo encuentra se lo conseguimos. Somos su mejor opción hoy y siempre.");
        }

        private void quienesSomosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Somos una empresa mexicana, que trata de apoyar al comercio mexicano, todos nuestros productos son 100% mexicanos, por que creemos en nosotros y por que sabemos que podemos");
        }

        private void misiónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Nuestra misión es darnos a conocer a nivel nacional y lograr el objetivo de que todos los mexicanos utilicen productos mexicanos, que abramos los ojos y veamos que no por que el producto sea de otro pais, signifique que es mejor");
        }

        private void visiónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Nuestra visión es que una vez que nos encontremos a nivel nacional, buscaremos el mercado internacional y llevaremos el nombre de nuestro producto, de nuestro pais, a todo el mundo para que sepan de lo que somos capaces");
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
