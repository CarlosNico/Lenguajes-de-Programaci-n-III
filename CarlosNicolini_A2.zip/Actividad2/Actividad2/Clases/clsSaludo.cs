﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad2.Clases
{
    public class clsSaludo
    {
        public string Saludar(string nombre)
        {
            string saludo;
            saludo = " Hola " + nombre + ", ¿Que tal va tu dia?";
            return saludo;
        }
    }
}
