﻿namespace Actividad2.Formularios
{
    partial class frminformacionpersonal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frminformacionpersonal));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.cmbestadocivil = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnregresar = new System.Windows.Forms.Button();
            this.rbt2 = new System.Windows.Forms.RadioButton();
            this.rbt1 = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txtapellido = new System.Windows.Forms.TextBox();
            this.txtdireccion = new System.Windows.Forms.TextBox();
            this.txtciudad = new System.Windows.Forms.TextBox();
            this.txtnombre = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnalergiano = new System.Windows.Forms.RadioButton();
            this.btnalergiasi = new System.Windows.Forms.RadioButton();
            this.cmbalergias = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cmbejercicio = new System.Windows.Forms.ComboBox();
            this.rbtejerciciono = new System.Windows.Forms.RadioButton();
            this.rbtejerciciosi = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbtoperadono1 = new System.Windows.Forms.RadioButton();
            this.rbtoperadono2 = new System.Windows.Forms.RadioButton();
            this.cmboperado = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtenfermedadsi = new System.Windows.Forms.RadioButton();
            this.rbtenfermedadno = new System.Windows.Forms.RadioButton();
            this.cmbenfermedad = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.rbtdepresionsi = new System.Windows.Forms.RadioButton();
            this.rbtdepresionno = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 6);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(640, 395);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tabPage1.BackgroundImage = global::Actividad2.Properties.Resources.Fondo_7;
            this.tabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tabPage1.Controls.Add(this.cmbestadocivil);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.btnregresar);
            this.tabPage1.Controls.Add(this.rbt2);
            this.tabPage1.Controls.Add(this.rbt1);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.dateTimePicker1);
            this.tabPage1.Controls.Add(this.txtapellido);
            this.tabPage1.Controls.Add(this.txtdireccion);
            this.tabPage1.Controls.Add(this.txtciudad);
            this.tabPage1.Controls.Add(this.txtnombre);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(632, 369);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Datos Personales";
            // 
            // cmbestadocivil
            // 
            this.cmbestadocivil.FormattingEnabled = true;
            this.cmbestadocivil.Items.AddRange(new object[] {
            "Soltero/a.",
            "Casado/a.",
            "Divorciado/a.",
            "Vuido/a."});
            this.cmbestadocivil.Location = new System.Drawing.Point(305, 205);
            this.cmbestadocivil.Name = "cmbestadocivil";
            this.cmbestadocivil.Size = new System.Drawing.Size(121, 21);
            this.cmbestadocivil.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 176);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 16);
            this.label7.TabIndex = 15;
            this.label7.Text = "Sexo";
            // 
            // btnregresar
            // 
            this.btnregresar.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnregresar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnregresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnregresar.Location = new System.Drawing.Point(539, 327);
            this.btnregresar.Name = "btnregresar";
            this.btnregresar.Size = new System.Drawing.Size(75, 36);
            this.btnregresar.TabIndex = 14;
            this.btnregresar.Text = "Regresar";
            this.btnregresar.UseVisualStyleBackColor = false;
            this.btnregresar.Click += new System.EventHandler(this.btnregresar_Click);
            // 
            // rbt2
            // 
            this.rbt2.AutoSize = true;
            this.rbt2.BackColor = System.Drawing.Color.Transparent;
            this.rbt2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbt2.Location = new System.Drawing.Point(9, 229);
            this.rbt2.Name = "rbt2";
            this.rbt2.Size = new System.Drawing.Size(56, 17);
            this.rbt2.TabIndex = 13;
            this.rbt2.TabStop = true;
            this.rbt2.Text = "Mujer";
            this.rbt2.UseVisualStyleBackColor = false;
            // 
            // rbt1
            // 
            this.rbt1.AutoSize = true;
            this.rbt1.BackColor = System.Drawing.Color.Transparent;
            this.rbt1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbt1.Location = new System.Drawing.Point(9, 206);
            this.rbt1.Name = "rbt1";
            this.rbt1.Size = new System.Drawing.Size(68, 17);
            this.rbt1.TabIndex = 12;
            this.rbt1.TabStop = true;
            this.rbt1.Text = "Hombre";
            this.rbt1.UseVisualStyleBackColor = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(311, 176);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 16);
            this.label6.TabIndex = 11;
            this.label6.Text = "Estado Civil";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 268);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "Fecha de Nacimiento";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(6, 298);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 8;
            // 
            // txtapellido
            // 
            this.txtapellido.Location = new System.Drawing.Point(118, 48);
            this.txtapellido.Name = "txtapellido";
            this.txtapellido.Size = new System.Drawing.Size(218, 20);
            this.txtapellido.TabIndex = 7;
            // 
            // txtdireccion
            // 
            this.txtdireccion.Location = new System.Drawing.Point(118, 79);
            this.txtdireccion.Name = "txtdireccion";
            this.txtdireccion.Size = new System.Drawing.Size(218, 20);
            this.txtdireccion.TabIndex = 6;
            // 
            // txtciudad
            // 
            this.txtciudad.Location = new System.Drawing.Point(118, 113);
            this.txtciudad.Name = "txtciudad";
            this.txtciudad.Size = new System.Drawing.Size(218, 20);
            this.txtciudad.TabIndex = 5;
            // 
            // txtnombre
            // 
            this.txtnombre.Location = new System.Drawing.Point(118, 17);
            this.txtnombre.Name = "txtnombre";
            this.txtnombre.Size = new System.Drawing.Size(218, 20);
            this.txtnombre.TabIndex = 4;
            this.txtnombre.TextChanged += new System.EventHandler(this.txtnombre_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(6, 52);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Apellido(s)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Dirección";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ciudad";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre(s)";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabPage2.BackgroundImage = global::Actividad2.Properties.Resources.Fondo_8;
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.rbtdepresionsi);
            this.tabPage2.Controls.Add(this.rbtdepresionno);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(632, 369);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Datos Clínicos";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.btnalergiano);
            this.groupBox4.Controls.Add(this.btnalergiasi);
            this.groupBox4.Controls.Add(this.cmbalergias);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(6, 224);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(609, 68);
            this.groupBox4.TabIndex = 39;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "¿Tienes Alergias?";
            // 
            // btnalergiano
            // 
            this.btnalergiano.AutoSize = true;
            this.btnalergiano.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnalergiano.Location = new System.Drawing.Point(6, 34);
            this.btnalergiano.Name = "btnalergiano";
            this.btnalergiano.Size = new System.Drawing.Size(39, 17);
            this.btnalergiano.TabIndex = 28;
            this.btnalergiano.Text = "No";
            this.btnalergiano.UseVisualStyleBackColor = true;
            // 
            // btnalergiasi
            // 
            this.btnalergiasi.AutoSize = true;
            this.btnalergiasi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnalergiasi.Location = new System.Drawing.Point(81, 34);
            this.btnalergiasi.Name = "btnalergiasi";
            this.btnalergiasi.Size = new System.Drawing.Size(34, 17);
            this.btnalergiasi.TabIndex = 29;
            this.btnalergiasi.Text = "Si";
            this.btnalergiasi.UseVisualStyleBackColor = true;
            // 
            // cmbalergias
            // 
            this.cmbalergias.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbalergias.FormattingEnabled = true;
            this.cmbalergias.Items.AddRange(new object[] {
            "Alergia a alimentos.",
            "Alergia a fármacos.",
            "Asma alérgico.",
            "Dermatitis atópica.",
            "Poliposis nasal.",
            "Rinitis alérgica.",
            "Urticaria crónica.",
            "Otro/a."});
            this.cmbalergias.Location = new System.Drawing.Point(140, 31);
            this.cmbalergias.Name = "cmbalergias";
            this.cmbalergias.Size = new System.Drawing.Size(410, 23);
            this.cmbalergias.TabIndex = 31;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.cmbejercicio);
            this.groupBox3.Controls.Add(this.rbtejerciciono);
            this.groupBox3.Controls.Add(this.rbtejerciciosi);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(6, 159);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(609, 59);
            this.groupBox3.TabIndex = 38;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "¿Haces ejercicio?";
            // 
            // cmbejercicio
            // 
            this.cmbejercicio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbejercicio.FormattingEnabled = true;
            this.cmbejercicio.Items.AddRange(new object[] {
            "Caminar cuesta arriba, trotar o correr.",
            "Ejercicios de calistenia intensos (lagartijas, flexiones abdominales, etc.)",
            "Baile aeróbico de alto impacto.",
            "Saltar la soga.",
            "Usar una escaladora o una máquina de esquí",
            "Usar una bicicleta fija, a intensidad fuerte.",
            "Otro/a."});
            this.cmbejercicio.Location = new System.Drawing.Point(140, 25);
            this.cmbejercicio.Name = "cmbejercicio";
            this.cmbejercicio.Size = new System.Drawing.Size(410, 23);
            this.cmbejercicio.TabIndex = 33;
            // 
            // rbtejerciciono
            // 
            this.rbtejerciciono.AutoSize = true;
            this.rbtejerciciono.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtejerciciono.Location = new System.Drawing.Point(6, 28);
            this.rbtejerciciono.Name = "rbtejerciciono";
            this.rbtejerciciono.Size = new System.Drawing.Size(39, 17);
            this.rbtejerciciono.TabIndex = 17;
            this.rbtejerciciono.Text = "No";
            this.rbtejerciciono.UseVisualStyleBackColor = true;
            // 
            // rbtejerciciosi
            // 
            this.rbtejerciciosi.AutoSize = true;
            this.rbtejerciciosi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtejerciciosi.Location = new System.Drawing.Point(81, 28);
            this.rbtejerciciosi.Name = "rbtejerciciosi";
            this.rbtejerciciosi.Size = new System.Drawing.Size(34, 17);
            this.rbtejerciciosi.TabIndex = 18;
            this.rbtejerciciosi.Text = "Si";
            this.rbtejerciciosi.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.rbtoperadono1);
            this.groupBox2.Controls.Add(this.rbtoperadono2);
            this.groupBox2.Controls.Add(this.cmboperado);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(6, 74);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(609, 78);
            this.groupBox2.TabIndex = 37;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "¿Alguna vez te han operado?";
            // 
            // rbtoperadono1
            // 
            this.rbtoperadono1.AutoSize = true;
            this.rbtoperadono1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtoperadono1.Location = new System.Drawing.Point(6, 32);
            this.rbtoperadono1.Name = "rbtoperadono1";
            this.rbtoperadono1.Size = new System.Drawing.Size(39, 17);
            this.rbtoperadono1.TabIndex = 15;
            this.rbtoperadono1.Text = "No";
            this.rbtoperadono1.UseVisualStyleBackColor = true;
            // 
            // rbtoperadono2
            // 
            this.rbtoperadono2.AutoSize = true;
            this.rbtoperadono2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtoperadono2.Location = new System.Drawing.Point(76, 35);
            this.rbtoperadono2.Name = "rbtoperadono2";
            this.rbtoperadono2.Size = new System.Drawing.Size(34, 17);
            this.rbtoperadono2.TabIndex = 16;
            this.rbtoperadono2.Text = "Si";
            this.rbtoperadono2.UseVisualStyleBackColor = true;
            // 
            // cmboperado
            // 
            this.cmboperado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmboperado.FormattingEnabled = true;
            this.cmboperado.Items.AddRange(new object[] {
            "Colecistectomia Laparoscópica(Extirpación de la vesícula biliar).",
            "Apendicectomía.",
            "Hernias.",
            "Hemorroidectomía.",
            "Biopsias.",
            "Otro/a."});
            this.cmboperado.Location = new System.Drawing.Point(140, 32);
            this.cmboperado.Name = "cmboperado";
            this.cmboperado.Size = new System.Drawing.Size(410, 23);
            this.cmboperado.TabIndex = 32;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.rbtenfermedadsi);
            this.groupBox1.Controls.Add(this.rbtenfermedadno);
            this.groupBox1.Controls.Add(this.cmbenfermedad);
            this.groupBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(609, 62);
            this.groupBox1.TabIndex = 36;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "¿Padeces de alguna enfermedad?";
            // 
            // rbtenfermedadsi
            // 
            this.rbtenfermedadsi.AutoSize = true;
            this.rbtenfermedadsi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtenfermedadsi.Location = new System.Drawing.Point(76, 25);
            this.rbtenfermedadsi.Name = "rbtenfermedadsi";
            this.rbtenfermedadsi.Size = new System.Drawing.Size(34, 17);
            this.rbtenfermedadsi.TabIndex = 32;
            this.rbtenfermedadsi.Text = "Si";
            this.rbtenfermedadsi.UseVisualStyleBackColor = true;
            // 
            // rbtenfermedadno
            // 
            this.rbtenfermedadno.AutoSize = true;
            this.rbtenfermedadno.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtenfermedadno.Location = new System.Drawing.Point(6, 25);
            this.rbtenfermedadno.Name = "rbtenfermedadno";
            this.rbtenfermedadno.Size = new System.Drawing.Size(39, 17);
            this.rbtenfermedadno.TabIndex = 31;
            this.rbtenfermedadno.Text = "No";
            this.rbtenfermedadno.UseVisualStyleBackColor = true;
            // 
            // cmbenfermedad
            // 
            this.cmbenfermedad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbenfermedad.FormattingEnabled = true;
            this.cmbenfermedad.Items.AddRange(new object[] {
            "Bronquitis aguda (resfriado de pecho).",
            "Resfriado común.",
            "Infección de oído.",
            "Influenza (gripe)",
            "Sinusitis (infección de los senos paranasales)",
            "Infecciones de la piel.",
            "Dolor de garganta.",
            "Infección urinaria.",
            "Otro/a."});
            this.cmbenfermedad.Location = new System.Drawing.Point(140, 21);
            this.cmbenfermedad.Name = "cmbenfermedad";
            this.cmbenfermedad.Size = new System.Drawing.Size(410, 23);
            this.cmbenfermedad.TabIndex = 30;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.Highlight;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(537, 329);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(78, 34);
            this.button2.TabIndex = 23;
            this.button2.Text = "Regresar";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // rbtdepresionsi
            // 
            this.rbtdepresionsi.AutoSize = true;
            this.rbtdepresionsi.BackColor = System.Drawing.Color.Transparent;
            this.rbtdepresionsi.Location = new System.Drawing.Point(87, 329);
            this.rbtdepresionsi.Name = "rbtdepresionsi";
            this.rbtdepresionsi.Size = new System.Drawing.Size(34, 17);
            this.rbtdepresionsi.TabIndex = 20;
            this.rbtdepresionsi.Text = "Si";
            this.rbtdepresionsi.UseVisualStyleBackColor = false;
            // 
            // rbtdepresionno
            // 
            this.rbtdepresionno.AutoSize = true;
            this.rbtdepresionno.BackColor = System.Drawing.Color.Transparent;
            this.rbtdepresionno.Location = new System.Drawing.Point(12, 329);
            this.rbtdepresionno.Name = "rbtdepresionno";
            this.rbtdepresionno.Size = new System.Drawing.Size(39, 17);
            this.rbtdepresionno.TabIndex = 19;
            this.rbtdepresionno.Text = "No";
            this.rbtdepresionno.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(9, 295);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(159, 16);
            this.label9.TabIndex = 2;
            this.label9.Text = "¿Padeces depresión?";
            // 
            // frminformacionpersonal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(659, 416);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frminformacionpersonal";
            this.Text = "Información Personal";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox txtapellido;
        private System.Windows.Forms.TextBox txtdireccion;
        private System.Windows.Forms.TextBox txtciudad;
        private System.Windows.Forms.TextBox txtnombre;
        private System.Windows.Forms.Button btnregresar;
        private System.Windows.Forms.RadioButton rbt2;
        private System.Windows.Forms.RadioButton rbt1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton rbtdepresionsi;
        private System.Windows.Forms.RadioButton rbtdepresionno;
        private System.Windows.Forms.RadioButton rbtejerciciosi;
        private System.Windows.Forms.RadioButton rbtejerciciono;
        private System.Windows.Forms.RadioButton rbtoperadono2;
        private System.Windows.Forms.RadioButton rbtoperadono1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.RadioButton btnalergiasi;
        private System.Windows.Forms.RadioButton btnalergiano;
        private System.Windows.Forms.ComboBox cmbestadocivil;
        private System.Windows.Forms.ComboBox cmbenfermedad;
        private System.Windows.Forms.ComboBox cmbejercicio;
        private System.Windows.Forms.ComboBox cmboperado;
        private System.Windows.Forms.ComboBox cmbalergias;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbtenfermedadsi;
        private System.Windows.Forms.RadioButton rbtenfermedadno;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
    }
}