﻿using Actividad2.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad2.Formularios
{
    public partial class frmoperacionesbasicas : Form
    {
        public frmoperacionesbasicas()
        {
            InitializeComponent();
        }

        /////   private void btnsuma_Click(object sender, EventArgs e)
        //   {
        //       int resultado;

        //       Clases.clsoperacionesbasicas clsoperacionesbasicasS = new Clases.clsoperacionesbasicas();
        //       resultado = clsoperacionesbasicasS.Sumar(int.Parse(txtnumero1.Text), int.Parse(txtnumero2.Text), int.Parse(txtnumero3.Text), int.Parse(txtnumero4.Text), int.Parse(txtnumero5.Text), int.Parse(txtnumero6.Text));
        //       txtresultado.Text = resultado.ToString();
        //   } 

        private void btnsuma_Click(object sender, EventArgs e)
        {
            if (txtnumero1.Text == "")
            { 
                MessageBox.Show("todos deben estar llenos");
        }
        else 
        {
            int resultado;

            Clases.clsoperacionesbasicas clsoperacionesbasicasS = new Clases.clsoperacionesbasicas();
            resultado = clsoperacionesbasicasS.Sumar(int.Parse(txtnumero1.Text), int.Parse(txtnumero2.Text), int.Parse(txtnumero3.Text), int.Parse(txtnumero4.Text), int.Parse(txtnumero5.Text), int.Parse(txtnumero6.Text));
            txtresultado.Text = resultado.ToString();
        }

        private void btnresta_Click(object sender, EventArgs e)
        {
            int resultado;

            Clases.clsoperacionesbasicas clsoperacionesbasicasR = new Clases.clsoperacionesbasicas();
            resultado = clsoperacionesbasicasR.Restar(int.Parse(txtnumero1.Text), int.Parse(txtnumero2.Text), int.Parse(txtnumero3.Text), int.Parse(txtnumero4.Text), int.Parse(txtnumero5.Text), int.Parse(txtnumero6.Text));
            txtresultado.Text = resultado.ToString();
        }

        private void btnmultiplicacion_Click(object sender, EventArgs e)
        {
            int resultado;

            Clases.clsoperacionesbasicas clsoperacionesbasicasM = new Clases.clsoperacionesbasicas();
            resultado = clsoperacionesbasicasM.Multiplicar(int.Parse(txtnumero1.Text), int.Parse(txtnumero2.Text), int.Parse(txtnumero3.Text), int.Parse(txtnumero4.Text), int.Parse(txtnumero5.Text), int.Parse(txtnumero6.Text));
            txtresultado.Text = resultado.ToString();
        }

        private void btndivision_Click(object sender, EventArgs e)
        {
            float resultado;

            Clases.clsoperacionesbasicas clsoperacionesbasicasD = new Clases.clsoperacionesbasicas();
            resultado = clsoperacionesbasicasD.Dividir(float.Parse(txtnumero1.Text), float.Parse(txtnumero2.Text), float.Parse(txtnumero3.Text), float.Parse(txtnumero4.Text), float.Parse(txtnumero5.Text), float.Parse(txtnumero6.Text));
            txtresultado.Text = resultado.ToString();
        }

        private void btnregresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnlimpiar_Click(object sender, EventArgs e)
        {
            txtnumero1.Clear();
            txtnumero2.Clear();
            txtnumero3.Clear();
            txtnumero4.Clear();
            txtnumero5.Clear();
            txtnumero6.Clear();
            txtresultado.Clear();
        }
    }
}
