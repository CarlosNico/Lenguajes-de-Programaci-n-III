﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad2.Clases
{
    public class clsoperacionesbasicas
    {

     //   public int Sumar(int numero1, int numero2, int numero3, int numero4, int numero5, int numero6)
      //  {
      //      int resultado;
      //      resultado = numero1 + numero2 + numero3 + numero4 + numero5 + numero6;
      //      if (numero1<> "") +(numero2<> "") +(numero3<> "") +(numero4<> "") +(numero5<> "") +(numero6<> "");
      //      return resultado;

      //  }

    public int Sumar(int numero1, int numero2, int numero3, int numero4, int numero5, int numero6)
        { 
            int resultado;
            resultado = numero1 + numero2 + numero3 + numero4 + numero5 + numero6;
            return resultado;
        }
        public int Restar(int numero1, int numero2, int numero3, int numero4, int numero5, int numero6)
        {
            int resultado;
            resultado = numero1 - numero2 - numero3 - numero4 - numero5 - numero6;
            return resultado;
        }
        public int Multiplicar(int numero1, int numero2, int numero3, int numero4, int numero5, int numero6)
        {
            int resultado;
            resultado = numero1 * numero2 * numero3 * numero4 * numero5 * numero6;
            return resultado;
        }
        public float Dividir(float numero1, float numero2, float numero3, float numero4, float numero5, float numero6)
        {
            float resultado;
            resultado = numero1 / numero2 / numero3 / numero4 / numero5 / numero6;
            return resultado;
        }
    }
}
