﻿namespace Actividad2.Formularios
{
    partial class frmoperacionesbasicas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmoperacionesbasicas));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnregresar = new System.Windows.Forms.Button();
            this.txtnumero1 = new System.Windows.Forms.TextBox();
            this.txtresultado = new System.Windows.Forms.TextBox();
            this.txtnumero6 = new System.Windows.Forms.TextBox();
            this.txtnumero5 = new System.Windows.Forms.TextBox();
            this.txtnumero4 = new System.Windows.Forms.TextBox();
            this.txtnumero3 = new System.Windows.Forms.TextBox();
            this.txtnumero2 = new System.Windows.Forms.TextBox();
            this.btnsuma = new System.Windows.Forms.Button();
            this.btndividir = new System.Windows.Forms.Button();
            this.btnmultiplicar = new System.Windows.Forms.Button();
            this.btnresta = new System.Windows.Forms.Button();
            this.btnlimpiar = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Número 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(476, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Resultado";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(311, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Número 6";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(164, 131);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Número 5";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Número 4";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(311, 52);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Número 3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(164, 52);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "Número 2";
            // 
            // btnregresar
            // 
            this.btnregresar.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnregresar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnregresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnregresar.Location = new System.Drawing.Point(651, 364);
            this.btnregresar.Name = "btnregresar";
            this.btnregresar.Size = new System.Drawing.Size(78, 32);
            this.btnregresar.TabIndex = 7;
            this.btnregresar.Text = "Regresar";
            this.btnregresar.UseVisualStyleBackColor = false;
            this.btnregresar.Click += new System.EventHandler(this.btnregresar_Click_1);
            // 
            // txtnumero1
            // 
            this.txtnumero1.Location = new System.Drawing.Point(12, 88);
            this.txtnumero1.Name = "txtnumero1";
            this.txtnumero1.Size = new System.Drawing.Size(86, 20);
            this.txtnumero1.TabIndex = 8;
            this.txtnumero1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtresultado
            // 
            this.txtresultado.Location = new System.Drawing.Point(480, 133);
            this.txtresultado.Name = "txtresultado";
            this.txtresultado.Size = new System.Drawing.Size(87, 20);
            this.txtresultado.TabIndex = 9;
            this.txtresultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtnumero6
            // 
            this.txtnumero6.Location = new System.Drawing.Point(315, 174);
            this.txtnumero6.Name = "txtnumero6";
            this.txtnumero6.Size = new System.Drawing.Size(82, 20);
            this.txtnumero6.TabIndex = 10;
            this.txtnumero6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtnumero5
            // 
            this.txtnumero5.Location = new System.Drawing.Point(159, 174);
            this.txtnumero5.Name = "txtnumero5";
            this.txtnumero5.Size = new System.Drawing.Size(91, 20);
            this.txtnumero5.TabIndex = 11;
            this.txtnumero5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtnumero4
            // 
            this.txtnumero4.Location = new System.Drawing.Point(12, 174);
            this.txtnumero4.Name = "txtnumero4";
            this.txtnumero4.Size = new System.Drawing.Size(86, 20);
            this.txtnumero4.TabIndex = 12;
            this.txtnumero4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtnumero3
            // 
            this.txtnumero3.Location = new System.Drawing.Point(315, 88);
            this.txtnumero3.Name = "txtnumero3";
            this.txtnumero3.Size = new System.Drawing.Size(82, 20);
            this.txtnumero3.TabIndex = 13;
            this.txtnumero3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtnumero2
            // 
            this.txtnumero2.Location = new System.Drawing.Point(159, 88);
            this.txtnumero2.Name = "txtnumero2";
            this.txtnumero2.Size = new System.Drawing.Size(91, 20);
            this.txtnumero2.TabIndex = 14;
            this.txtnumero2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnsuma
            // 
            this.btnsuma.BackColor = System.Drawing.Color.SandyBrown;
            this.btnsuma.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnsuma.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsuma.Location = new System.Drawing.Point(16, 264);
            this.btnsuma.Name = "btnsuma";
            this.btnsuma.Size = new System.Drawing.Size(93, 45);
            this.btnsuma.TabIndex = 15;
            this.btnsuma.Text = "Suma";
            this.btnsuma.UseVisualStyleBackColor = false;
            this.btnsuma.Click += new System.EventHandler(this.btnsuma_Click);
            // 
            // btndividir
            // 
            this.btndividir.BackColor = System.Drawing.Color.Gold;
            this.btndividir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btndividir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndividir.Location = new System.Drawing.Point(473, 264);
            this.btndividir.Name = "btndividir";
            this.btndividir.Size = new System.Drawing.Size(94, 45);
            this.btndividir.TabIndex = 16;
            this.btndividir.Text = "Dividisión";
            this.btndividir.UseVisualStyleBackColor = false;
            this.btndividir.Click += new System.EventHandler(this.btndividir_Click);
            // 
            // btnmultiplicar
            // 
            this.btnmultiplicar.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnmultiplicar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnmultiplicar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmultiplicar.Location = new System.Drawing.Point(312, 264);
            this.btnmultiplicar.Name = "btnmultiplicar";
            this.btnmultiplicar.Size = new System.Drawing.Size(94, 45);
            this.btnmultiplicar.TabIndex = 17;
            this.btnmultiplicar.Text = "Multiplicación";
            this.btnmultiplicar.UseVisualStyleBackColor = false;
            this.btnmultiplicar.Click += new System.EventHandler(this.btnmultiplicar_Click);
            // 
            // btnresta
            // 
            this.btnresta.BackColor = System.Drawing.Color.Tan;
            this.btnresta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnresta.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnresta.Location = new System.Drawing.Point(159, 264);
            this.btnresta.Name = "btnresta";
            this.btnresta.Size = new System.Drawing.Size(101, 45);
            this.btnresta.TabIndex = 18;
            this.btnresta.Text = "Resta";
            this.btnresta.UseVisualStyleBackColor = false;
            this.btnresta.Click += new System.EventHandler(this.btnresta_Click_1);
            // 
            // btnlimpiar
            // 
            this.btnlimpiar.BackColor = System.Drawing.SystemColors.Info;
            this.btnlimpiar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnlimpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlimpiar.Location = new System.Drawing.Point(244, 355);
            this.btnlimpiar.Name = "btnlimpiar";
            this.btnlimpiar.Size = new System.Drawing.Size(91, 41);
            this.btnlimpiar.TabIndex = 19;
            this.btnlimpiar.Text = "Limpiar";
            this.btnlimpiar.UseVisualStyleBackColor = false;
            this.btnlimpiar.Click += new System.EventHandler(this.btnlimpiar_Click_1);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(9, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(748, 15);
            this.label8.TabIndex = 20;
            this.label8.Text = "Esta calculadora de operaciones basicas nos permitira realizar suma, resta, multi" +
    "plicacion y division de 6 numeros.";
            // 
            // frmoperacionesbasicas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = global::Actividad2.Properties.Resources.Fondo_9;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(752, 417);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnlimpiar);
            this.Controls.Add(this.btnresta);
            this.Controls.Add(this.btnmultiplicar);
            this.Controls.Add(this.btndividir);
            this.Controls.Add(this.btnsuma);
            this.Controls.Add(this.txtnumero2);
            this.Controls.Add(this.txtnumero3);
            this.Controls.Add(this.txtnumero4);
            this.Controls.Add(this.txtnumero5);
            this.Controls.Add(this.txtnumero6);
            this.Controls.Add(this.txtresultado);
            this.Controls.Add(this.txtnumero1);
            this.Controls.Add(this.btnregresar);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmoperacionesbasicas";
            this.Text = "Operaciones Basicas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnregresar;
        private System.Windows.Forms.TextBox txtnumero1;
        private System.Windows.Forms.TextBox txtresultado;
        private System.Windows.Forms.TextBox txtnumero6;
        private System.Windows.Forms.TextBox txtnumero5;
        private System.Windows.Forms.TextBox txtnumero4;
        private System.Windows.Forms.TextBox txtnumero3;
        private System.Windows.Forms.TextBox txtnumero2;
        private System.Windows.Forms.Button btnsuma;
        private System.Windows.Forms.Button btndividir;
        private System.Windows.Forms.Button btnmultiplicar;
        private System.Windows.Forms.Button btnresta;
        private System.Windows.Forms.Button btnlimpiar;
        private System.Windows.Forms.Label label8;
    }
}