﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad2
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtcontrasena.Text == "")
                MessageBox.Show("Por favor ingresar contraseña");
            else if (txtcontrasena.Text == "Umi80")
            {
                Form1 frmPrincipal = new Form1();
                frmPrincipal.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Contraseña incorrecta");
                txtcontrasena.Clear();      
            }
        }
    }
}
